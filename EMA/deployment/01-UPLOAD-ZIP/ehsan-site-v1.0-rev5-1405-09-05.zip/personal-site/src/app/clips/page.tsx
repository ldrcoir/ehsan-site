// ============================================================================
// /clips — صفحه نمایش کلیپ‌های آپارات
// ============================================================================
"use client";
import { sanitizeEmbed } from "@/lib/sanitize-embed";
import ThemeApplier from "@/components/ThemeApplier"; // v1.1.2: تم/فونت پیش‌فرض DB روی این صفحه هم اعمال شود

import { useEffect, useState } from "react";

type Clip = {
  id: string;
  title: string;
  embedCode: string;
  description: string;
  category: string;
};

export default function ClipsPage() {
  const [clips, setClips] = useState<Clip[]>([]);
  const [loading, setLoading] = useState(true);
  // v1.0 rev3 (audit BUG-c LOW): عنوان/پیام خالی سه‌زبانه شدند — قبلاً برای همه‌ی
  // زبان‌ها فارسی بود؛ زبان از مرورگر تشخیص داده می‌شود (fa→فارسی، بقیه→English)
  const [isFa, setIsFa] = useState(true);

  useEffect(() => {
    try {
      const nav = (typeof navigator !== "undefined" && navigator.language) || "";
      setIsFa(nav.toLowerCase().startsWith("fa"));
    } catch {
      setIsFa(true);
    }
  }, []);

  useEffect(() => {
    fetch("/api/clips")
      .then((r) => r.json())
      .then((data) => {
        if (data.ok) setClips(data.clips || []);
      })
      // v1.1.1 (audit Q3): خطای شبکه دیگر unhandled rejection نیست
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--bg, #000)", color: "var(--fg, #00ff41)", fontFamily: "monospace" }}>
        <ThemeApplier />
        ...
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg, #000)", color: "var(--fg-soft, #c8ffc8)", fontFamily: "monospace", padding: 20 }}>
      <ThemeApplier />
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        <h1 style={{ color: "var(--fg, #00ff41)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 30 }}>
          {isFa ? "🎬 کلیپ‌ها" : "🎬 Clips"}
        </h1>

        {clips.length === 0 ? (
          <p style={{ color: "var(--muted, #4a7a4a)", textAlign: "center", padding: 40 }}>
            {isFa ? "هنوز کلیپی اضافه نشده." : "No clips yet."}
          </p>
        ) : (
          <div style={{ display: "grid", gap: 30 }}>
            {clips.map((clip) => (
              <div key={clip.id} style={{ background: "var(--bg-deep, #050505)", border: "1px solid var(--border, #1a3a1a)", borderRadius: 8, overflow: "hidden" }}>
                <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border, #1a3a1a)" }}>
                  <h2 style={{ color: "var(--accent, #39ff14)", margin: 0, fontSize: 16 }}>{clip.title}</h2>
                  {clip.description && <p style={{ color: "var(--muted, #4a7a4a)", fontSize: 11, marginTop: 4 }}>{clip.description}</p>}
                </div>
                <div style={{ aspectRatio: "16/9", background: "var(--bg, #000)" }} dangerouslySetInnerHTML={{ __html: sanitizeEmbed(clip.embedCode) }} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
