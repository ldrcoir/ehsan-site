import { NextResponse } from "next/server";
import { getClientIpSafe } from "@/lib/ip";
import { db } from "@/lib/db";
import { logSecurityEvent, isIpBlocked } from "@/lib/security";

// Simple in-memory rate limiter: max 3 messages per IP per 10 minutes
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000;
const RATE_LIMIT_MAX = 3;
const hits = new Map<string, number[]>();
// v1.0 (audit W26-30 #6): سقف سخت روی کلیدها — IP rotation بین دو پاکسازی
// می‌توانست Map را بی‌رویه بزرگ کند (هم‌الگو با middleware)
const HITS_MAP_MAX = 10000;

// V17.4: پاکسازی دوره‌ای Map برای جلوگیری از memory leak
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [k, arr] of hits) {
      const fresh = arr.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
      if (fresh.length === 0) hits.delete(k);
      else hits.set(k, fresh);
    }
  }, 5 * 60 * 1000).unref?.();
}

function rateLimit(ip: string): boolean {
  // Skip rate limit in development for localhost
  if (process.env.NODE_ENV !== "production" && (ip === "::1" || ip === "127.0.0.1" || ip === "unknown")) {
    return true;
  }
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS);
  if (arr.length >= RATE_LIMIT_MAX) return false;
  arr.push(now);
  hits.set(ip, arr);
  // v1.0 (audit W26-30 #6): سقف سخت تعداد کلیدها
  if (hits.size > HITS_MAP_MAX) {
    const oldestKey = hits.keys().next().value;
    if (oldestKey !== undefined) hits.delete(oldestKey);
  }
  return true;
}

function isSpammy(text: string): boolean {
  const lower = text.toLowerCase();
  // Common spam patterns
  // v1.1.2 (audit SEC-06): الگوی URL بدون backtracking مرسومی — شمارش لینک‌ها به‌صورت خطی
  let urlCount = 0;
  const urlRe = /https?:\/\/\S+/g;
  while (urlRe.exec(lower) !== null) {
    urlCount++;
    if (urlCount >= 3) break;
  }
  const spamPatterns: RegExp[] = [
    /\b(viagra|cialis|casino|lottery|prize|winner|bitcoin investment)\b/,
    /(.)\1{10,}/, // 11+ of same char in a row
  ];
  return urlCount >= 3 || spamPatterns.some((re) => re.test(lower));
}

export async function POST(req: Request) {
  try {
    // v1.1.2 (audit SEC-16): سقف حجم بدنه قبل از parse — حداکثر 64KB کافی است
    const cl = parseInt(req.headers.get("content-length") || "0", 10);
    if (cl > 64 * 1024) {
      return NextResponse.json({ ok: false, error: "payload_too_large" }, { status: 413 });
    }
    // V18.2: use shared IP helper
    const ip = getClientIpSafe(req);
    // v1.0 (audit W16-20 #3): IP مسدودشده حق ارسال فرم تماس ندارد — هم‌مثل login/chat
    if (ip !== "unknown" && (await isIpBlocked(ip))) {
      return NextResponse.json({ ok: false, error: "ip_blocked" }, { status: 403 });
    }
    // v1.0 (audit W41-45 #12): UA clamp — قبلاً هدر خام تا 16KB در DB ذخیره می‌شد
    const userAgent = (req.headers.get("user-agent") || "").slice(0, 300);

    // Bot detection
    if (/bot|crawl|spider|slurp|wget|curl/i.test(userAgent) && userAgent.length < 80) {
      return NextResponse.json(
        { ok: false, error: "Blocked" },
        { status: 403 }
      );
    }

    if (!rateLimit(ip)) {
      return NextResponse.json(
        { ok: false, error: "rate_limit" },
        { status: 429 }
      );
    }

    const body = await req.json().catch(() => null);
    if (!body) {
      return NextResponse.json(
        { ok: false, error: "invalid_body" },
        { status: 400 }
      );
    }

    const name = String(body.name || "").trim().slice(0, 100);
    const email = String(body.email || "").trim().slice(0, 200);
    const message = String(body.message || "").trim().slice(0, 5000);
    // honeypot — فیلد مخفی که بات‌ها پر می‌کنن، انسان‌ها نباید
    const website = String(body.website || "").trim();
    if (website) {
      // بات این فیلد رو پر کرده — رد کن بدون اینکه بهش بگیم چرا
      await logSecurityEvent("honeypot_triggered", ip, `Bot honeypot filled: ${website.slice(0, 50)}`);
      // به ظاهر موفق برگردون تا بات نفهمه
      return NextResponse.json({ ok: true });
    }
    // time-trap — اگه فرم خیلی سریع submit شده (کمتر از ۲ ثانیه)، احتمالاً بات
    // V17.7: FAIL-CLOSED — اگه _t نامعتبر، صفر، یا نباشه، رد کن (نه اجازه بده)
    const submittedAtRaw = body._t;
    let submittedAt: number;
    if (typeof submittedAtRaw === "number" && submittedAtRaw > 0) {
      submittedAt = submittedAtRaw;
    } else if (typeof submittedAtRaw === "string" && /^\d+$/.test(submittedAtRaw) && parseInt(submittedAtRaw, 10) > 0) {
      submittedAt = parseInt(submittedAtRaw, 10);
    } else {
      // _t نامعتبر یا غایب — fail-closed ولی بی‌صدا (v1.1: مثل honeypot ok برمی‌گردونیم
      // تا tripwire برای نویسنده‌ی بات افشا نشه)
      await logSecurityEvent("time_trap_triggered", ip, `Invalid or missing _t: ${String(submittedAtRaw).slice(0, 30)}`);
      return NextResponse.json({ ok: true });
    }
    // اگه کمتر از ۲ ثانیه از نمایش فرم گذشته، رد کن — v1.1: بی‌صدا
    const elapsed = Date.now() - submittedAt;
    if (elapsed < 2000) {
      await logSecurityEvent("time_trap_triggered", ip, `Form submitted too fast: ${elapsed}ms`);
      return NextResponse.json({ ok: true });
    }

    // === reCAPTCHA VERIFICATION — mandatory + fail-closed ===
    // توکن reCAPTCHA اجباریه. اگه نباشه یا نامعتبر باشه، رد می‌شه.
    // در صورت خطای شبکه، هم رد می‌شه (fail-closed).
    const recaptchaToken = body.recaptchaToken;
    if (!recaptchaToken || typeof recaptchaToken !== "string" || recaptchaToken.length < 10) {
      await logSecurityEvent("captcha_missing", ip, "reCAPTCHA token missing");
      return NextResponse.json(
        { ok: false, error: "captcha_required" },
        { status: 400 }
      );
    }
    let captchaOk = false;
    try {
      const verifyRes = await fetch("https://www.google.com/recaptcha/api/siteverify", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        // v1.1 (security): timeout — یک اتصال سیاه‌شده می‌توانست handler را دقیقه‌ها
        // نگه دارد و آمپلی‌فیکیشن DoS بسازد
        signal: AbortSignal.timeout(5000),
        // v1.1.2 (audit SEC-08-L): redirect manual — هم‌تراز با بقیه‌ی fetchهای سرور
        redirect: "manual",
        body: new URLSearchParams({
          secret: process.env.RECAPTCHA_SECRET || "",
          response: recaptchaToken,
          // v1.0 (audit W26-30 #7): اتصال توکن به IP درخواست‌کننده (defense-in-depth)
          ...(ip !== "unknown" ? { remoteip: ip } : {}),
        }).toString(),
      });
      const verifyData = await verifyRes.json();
      captchaOk = !!verifyData.success;
      if (!captchaOk) {
        await logSecurityEvent("captcha_failed", ip, `reCAPTCHA verification failed: ${JSON.stringify(verifyData["error-codes"] || [])}`);
      }
    } catch (e) {
      await logSecurityEvent("captcha_failed", ip, `reCAPTCHA network error: ${String(e).slice(0, 100)}`);
      // fail-closed: در صورت خطای شبکه، پیام رد می‌شه
    }
    if (!captchaOk) {
      return NextResponse.json(
        { ok: false, error: "captcha_failed" },
        { status: 400 }
      );
    }

    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!name || !email || !message) {
      return NextResponse.json(
        { ok: false, error: "missing_fields" },
        { status: 400 }
      );
    }
    if (!emailRe.test(email)) {
      return NextResponse.json(
        { ok: false, error: "invalid_email" },
        { status: 400 }
      );
    }
    if (message.length < 10) {
      return NextResponse.json(
        { ok: false, error: "message_too_short" },
        { status: 400 }
      );
    }
    if (isSpammy(message)) {
      return NextResponse.json(
        { ok: false, error: "spam_detected" },
        { status: 422 }
      );
    }

    const saved = await db.contactMessage.create({
      data: { name, email, message, ip, userAgent },
    });

    // Send Bale notification (async, non-blocking)
    import("@/lib/bale")
      .then(({ notifyNewContactMessage }) =>
        notifyNewContactMessage({ id: saved.id, name, email, message })
      )
      .catch(() => {});

    // V18.0: Send Telegram notification (was never wired — dead code)
    import("@/lib/telegram")
      .then(({ notifyTelegramContactMessage }) =>
        notifyTelegramContactMessage({ id: saved.id, name, email, message })
      )
      .catch(() => {});

    // Forward to admin's email via formsubmit.co (async, non-blocking)
    import("@/lib/settings")
      .then(async ({ getSetting }) => {
        const forwardEmail = await getSetting("forwardEmail");
        if (forwardEmail) {
          // v1.1.1 (audit S5-L4): encodeURIComponent + timeout + redirect manual
          await fetch(`https://formsubmit.co/ajax/${encodeURIComponent(forwardEmail)}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            redirect: "manual",
            signal: AbortSignal.timeout(10_000),
            body: JSON.stringify({
              _subject: `📨 New message from ${name}`,
              _template: "table",
              _captcha: "false",
              name, email, message,
              submitted_at: new Date().toISOString(),
            }),
          }).catch(() => {});
        }
      })
      .catch(() => {});

    return NextResponse.json({
      ok: true,
      id: saved.id,
      receivedAt: saved.createdAt,
    });
  } catch (err) {
    console.error("[/api/contact] error:", err);
    return NextResponse.json(
      { ok: false, error: "server_error" },
      { status: 500 }
    );
  }
}
