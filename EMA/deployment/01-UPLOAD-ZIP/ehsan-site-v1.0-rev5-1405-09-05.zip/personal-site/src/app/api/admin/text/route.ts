import { checkAdminAuth, TAB_PERMISSIONS } from "@/lib/admin-auth";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isElevated } from "@/lib/rbac";

// v1.0 (audit W11-15 #2 — MEDIUM): کلیدهای حساس AI — فقط ادمین. تب «متن‌ها» قابل
// واگذاری به کاربر limited است؛ ai.system_prompt مستقیماً system prompt چت را
// می‌سازد — یک content-editor کم‌دسترسی نباید بتواند شخصیتِ چبات‌bot سایت را
// بازنویسی کند (prompt injection در نام دامنه‌ی خود صاحب سایت).
const AI_ADMIN_ONLY_TEXT_PREFIXES = ["ai."];
function isAiAdminOnlyKey(key: string): boolean {
  const k = key.toLowerCase();
  return AI_ADMIN_ONLY_TEXT_PREFIXES.some((p) => k.startsWith(p));
}

/**
 * GET /api/admin/text?password=xxx
 * Returns all site text strings.
 *
 * POST /api/admin/text
 * { password, action: "set", key, valueEn, valueFa, valueDe }
 * { password, action: "bulk_set", items: [{key, valueEn, valueFa, valueDe}] }
 * { password, action: "delete", key }   — V1.1: remove a text key entirely
 */
export async function GET(req: Request) {
  try {
    const authCheck = await checkAdminAuth(req, TAB_PERMISSIONS["/api/admin/text"]);
    if (!authCheck.ok) {
      // V18.3: public branch removed — was returning data without proper auth
      // Public text content is available via /api/content (which has PUBLIC_KEYS filter)
      return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
    }

    // Admin — return all languages
    // v1.0 rev3 (audit SEC-a LOW): خواندن هم هم‌تراز با نوشتن محدود شد —
    // کاربر limited با تب «متن‌ها» نباید ai.* (system prompt چت) را بخواند
    const isAdminRead = isElevated(authCheck.role);
    const texts = await db.siteText.findMany();
    const result: Record<string, { en: string; fa: string; de: string }> = {};
    for (const t of texts) {
      if (!isAdminRead && isAiAdminOnlyKey(t.key)) continue;
      result[t.key] = { en: t.valueEn, fa: t.valueFa, de: t.valueDe };
    }
    return NextResponse.json({ ok: true, texts: result });
  } catch (err) {
    console.error("[/api/admin/text GET]", err);
    return NextResponse.json({ ok: false, error: "server_error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    if (!body) return NextResponse.json({ ok: false, error: "invalid_body" }, { status: 400 });

    // V18.3: dead password param removed (checkAdminAuth ignores it)
    const authCheck = await checkAdminAuth(req, TAB_PERMISSIONS["/api/admin/text"]); if (!authCheck.ok) {
      return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
    }
    // v1.0 (audit W11-15 #2): نوشتنِ کلیدهای ai.* فقط برای ادمین — کاربر limited 403 می‌گیرد
    // v1.0 (RBAC cleanup): isElevated — owner هم شامل می‌شود
    const isAdmin = isElevated(authCheck.role);

    const action = String(body.action || "");

    switch (action) {
      case "set": {
        const key = String(body.key || "");
        if (!key) return NextResponse.json({ ok: false, error: "missing_key" }, { status: 400 });
        if (!isAdmin && isAiAdminOnlyKey(key)) {
          return NextResponse.json({ ok: false, error: "admin_only_key" }, { status: 403 });
        }
        // v1.1.2 (hardening): cap key at 200 chars and values at 10000 chars
        if (key.length > 200) {
          return NextResponse.json({ ok: false, error: "key_too_long" }, { status: 400 });
        }
        const valueEn = String(body.valueEn || "");
        const valueFa = String(body.valueFa || "");
        const valueDe = String(body.valueDe || "");
        if (valueEn.length > 10000 || valueFa.length > 10000 || valueDe.length > 10000) {
          return NextResponse.json({ ok: false, error: "value_too_long" }, { status: 400 });
        }
        await db.siteText.upsert({
          where: { key },
          update: { valueEn, valueFa, valueDe },
          create: { key, valueEn, valueFa, valueDe },
        });
        return NextResponse.json({ ok: true });
      }

      case "bulk_set": {
        const items = body.items || [];
        if (!Array.isArray(items)) {
          return NextResponse.json({ ok: false, error: "no_items" }, { status: 400 });
        }
        // v1.0 (audit W11-15 #2): bulk هم ai.* را برای کاربر limited رد می‌کند (بدون partial write)
        if (!isAdmin && items.some((it: { key?: unknown }) => isAiAdminOnlyKey(String(it?.key || "")))) {
          return NextResponse.json({ ok: false, error: "admin_only_key" }, { status: 403 });
        }
        // v1.1.2 (hardening): cap batch size at 300
        if (items.length > 300) {
          return NextResponse.json({ ok: false, error: "too_many_items" }, { status: 400 });
        }
        // v1.1.2 (hardening): validate caps for every item before writing (no partial writes)
        for (const item of items) {
          const key = String(item.key || "");
          if (key.length > 200) {
            return NextResponse.json({ ok: false, error: "key_too_long" }, { status: 400 });
          }
          const values = [String(item.valueEn || ""), String(item.valueFa || ""), String(item.valueDe || "")];
          if (values.some((v) => v.length > 10000)) {
            return NextResponse.json({ ok: false, error: "value_too_long" }, { status: 400 });
          }
        }
        for (const item of items) {
          await db.siteText.upsert({
            where: { key: String(item.key) },
            update: {
              valueEn: String(item.valueEn || ""),
              valueFa: String(item.valueFa || ""),
              valueDe: String(item.valueDe || ""),
            },
            create: {
              key: String(item.key),
              valueEn: String(item.valueEn || ""),
              valueFa: String(item.valueFa || ""),
              valueDe: String(item.valueDe || ""),
            },
          });
        }
        return NextResponse.json({ ok: true, count: items.length });
      }

      // V1.1: delete a text key (used by the 🗑 button in TextEditor)
      case "delete": {
        const key = String(body.key || "");
        if (!key) return NextResponse.json({ ok: false, error: "missing_key" }, { status: 400 });
        if (!isAdmin && isAiAdminOnlyKey(key)) {
          return NextResponse.json({ ok: false, error: "admin_only_key" }, { status: 403 });
        }
        // deleteMany → idempotent (no error if the key doesn't exist)
        const res = await db.siteText.deleteMany({ where: { key } });
        return NextResponse.json({ ok: true, deleted: res.count });
      }

      default:
        return NextResponse.json({ ok: false, error: "invalid_action" }, { status: 400 });
    }
  } catch (err) {
    console.error("[/api/admin/text POST]", err);
    return NextResponse.json({ ok: false, error: "server_error" }, { status: 500 });
  }
}
