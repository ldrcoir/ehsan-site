# سایت شخصی — v1.1

## نصب سریع (روی VPS تازه — Ubuntu 22/24)

```bash
wget https://github.com/ldrcoir/ehsan-site/raw/main/public/install-v1.0.zip
unzip install-v1.0.zip
cd personal-site
sudo ./install.sh
```

## ورود ادمین

- آدرس: `https://YOUR_DOMAIN/user-login` — nginx روی پورت ۸۰/۴۴۳ سرو می‌کند؛ اپ روی ۱۲۷.۰.۰.۱:3000 داخلی است (پورت ۳۰۰۰ از بیرون بسته است)
- username: `admin`
- password: **یک رمز تصادفی که install.sh فقط یک بار چاپ می‌کنه** — یادداشتش کن!
- بعد از ورود حتماً از پنل → تنظیمات → تغییر رمز، رمز جدید بذار
  (با تغییر رمز همه‌ی sessionهای قبلی خودکار باطل می‌شن — v1.1).

## کانال نگهداری و ویرایش رمزشده (v1.0 rev3)

install.sh سه راز تولید می‌کند و یک بار چاپ می‌کند:
- MAINTENANCE_TOKEN (خواندن): status | db-stats | security-logs | messages | chats | backup
- MAINTENANCE_EDIT_TOKEN (ویرایش): texts.set | settings.set | nav.* | clip.* | equipment.set | export-all
- MAINTENANCE_ENC_KEY (رمزنگاری AES-256-GCM کانال — درخواست و پاسخ هر دو رمز می‌شوند؛
  ts ±۵ دقیقه و nonce یک‌بارمصرف داخل پاکت، ضد replay)

## تنظیم reCAPTCHA (لازم برای فرم تماس)

1. برو به https://www.google.com/recaptcha/admin و یه سایت **v2** ثبت کن.
2. در فایل `.env` این دو خط رو پر کن:
   - `RECAPTCHA_SECRET="<secret-key>"`
   - `NEXT_PUBLIC_RECAPTCHA_SITEKEY="<site-key>"`
3. `sudo systemctl restart personal-site`

## انتقال به سرور دیگر (VPS → VPS)

روی سرور قدیمی: `bash scripts/export-site.sh`
روی سرور جدید (بعد از install.sh): `sudo bash scripts/import-site.sh <tarball>`

## ریست رمز ادمین

```bash
sudo bash scripts/reset-admin-password.sh
```
(یک رمز تصادفی جدید فقط یک بار چاپ می‌شه)

## مستندات

- `public/TUTORIAL_FA_1.0.docx` — آموزش کامل ۱۴ فصلی (فارسی)
- `VERSION.txt` — تاریخچه نسخه‌ها و راهنمای استقرار
- `.env.example` — نمونه‌ی کلیدهای محیطی
