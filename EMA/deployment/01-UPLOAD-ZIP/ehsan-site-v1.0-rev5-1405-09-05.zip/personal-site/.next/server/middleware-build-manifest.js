globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/EJt72nzAkTl2jeJpxzY04/_buildManifest.js",
    "static/EJt72nzAkTl2jeJpxzY04/_ssgManifest.js",
    "static/EJt72nzAkTl2jeJpxzY04/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/2e_lrwr-bf1eq.js",
    "static/chunks/0542cuk_va8g1.js",
    "static/chunks/turbopack-442bkmmtp-hud.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
