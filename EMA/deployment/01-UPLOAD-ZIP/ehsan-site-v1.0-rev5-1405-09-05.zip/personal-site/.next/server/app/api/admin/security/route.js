var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/security/route.js")
R.c("server/chunks/[root-of-the-server]__12szab-._.js")
R.c("server/chunks/_0rzronk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_security_route_actions_0cf6pa-.js")
R.m(81922)
module.exports=R.m(81922).exports
