var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0itt02-._.js")
R.c("server/chunks/_018xrcs._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_user_logout_route_actions_1zg9wjl.js")
R.m(72058)
module.exports=R.m(72058).exports
