var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__12szab-._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0z0zrlu._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_[id]_route_actions_1hhpuc4.js")
R.m(84085)
module.exports=R.m(84085).exports
