var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/providers/route.js")
R.c("server/chunks/[externals]_dns_1dcnv4p._.js")
R.c("server/chunks/_1lyu9op._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__03cwx75._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_providers_route_actions_10mjyua.js")
R.m(79278)
module.exports=R.m(79278).exports
