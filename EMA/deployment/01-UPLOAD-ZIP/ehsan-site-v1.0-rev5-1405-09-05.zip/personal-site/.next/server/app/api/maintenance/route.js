var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/maintenance/route.js")
R.c("server/chunks/[root-of-the-server]__173g5p2._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__209wp0i._.js")
R.c("server/chunks/_next-internal_server_app_api_maintenance_route_actions_0pnh5ps.js")
R.m(93003)
module.exports=R.m(93003).exports
