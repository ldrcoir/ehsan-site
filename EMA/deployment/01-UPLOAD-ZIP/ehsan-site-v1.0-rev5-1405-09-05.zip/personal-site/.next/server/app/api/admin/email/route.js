var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/email/route.js")
R.c("server/chunks/[root-of-the-server]__12szab-._.js")
R.c("server/chunks/_1_sj3k7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_email_route_actions_00vta_3.js")
R.m(20194)
module.exports=R.m(20194).exports
