var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/chat-reply/route.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0pov59u._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_chat-reply_route_actions_13vxz5l.js")
R.m(3975)
module.exports=R.m(3975).exports
