var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/themes/route.js")
R.c("server/chunks/[root-of-the-server]__12szab-._.js")
R.c("server/chunks/_0x5i0kx._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_themes_route_actions_1vhvz3j.js")
R.m(69723)
module.exports=R.m(69723).exports
