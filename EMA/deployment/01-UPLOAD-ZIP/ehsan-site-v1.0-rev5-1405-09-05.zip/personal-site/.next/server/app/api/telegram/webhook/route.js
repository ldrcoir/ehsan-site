var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/telegram/webhook/route.js")
R.c("server/chunks/src_lib_security_ts_0i3ym6o._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0q0da1r._.js")
R.c("server/chunks/_next-internal_server_app_api_telegram_webhook_route_actions_06_s6l7.js")
R.m(88178)
module.exports=R.m(88178).exports
