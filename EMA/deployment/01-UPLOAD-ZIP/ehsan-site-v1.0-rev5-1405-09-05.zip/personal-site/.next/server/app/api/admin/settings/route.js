var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/route.js")
R.c("server/chunks/src_lib_telegram_ts_0ysg2aj._.js")
R.c("server/chunks/_0oqv97q._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__19w7kuw._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_settings_route_actions_20mpcqu.js")
R.m(11094)
module.exports=R.m(11094).exports
