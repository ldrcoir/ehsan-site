var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/messages/route.js")
R.c("server/chunks/[root-of-the-server]__19wa2f6._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_1qnv-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_messages_route_actions_0j2ylxp.js")
R.m(25564)
module.exports=R.m(25564).exports
