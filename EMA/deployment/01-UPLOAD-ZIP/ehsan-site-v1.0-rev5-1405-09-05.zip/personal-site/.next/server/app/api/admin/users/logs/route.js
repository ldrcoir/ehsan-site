var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/logs/route.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0749zyb._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_logs_route_actions_1q4xw9g.js")
R.m(26233)
module.exports=R.m(26233).exports
