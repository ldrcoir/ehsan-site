var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/login/route.js")
R.c("server/chunks/[root-of-the-server]__1vql0t2._.js")
R.c("server/chunks/_1qtvl14._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_user_login_route_actions_11c_gi4.js")
R.m(22946)
module.exports=R.m(22946).exports
