var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/verify/route.js")
R.c("server/chunks/[root-of-the-server]__0itt02-._.js")
R.c("server/chunks/_1p24rzb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_user_verify_route_actions_1b9317e.js")
R.m(82996)
module.exports=R.m(82996).exports
