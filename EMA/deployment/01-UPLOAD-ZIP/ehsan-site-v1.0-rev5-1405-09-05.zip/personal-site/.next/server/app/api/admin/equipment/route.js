var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/equipment/route.js")
R.c("server/chunks/[root-of-the-server]__12szab-._.js")
R.c("server/chunks/_14u0gka._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_equipment_route_actions_0bv23hz.js")
R.m(91791)
module.exports=R.m(91791).exports
