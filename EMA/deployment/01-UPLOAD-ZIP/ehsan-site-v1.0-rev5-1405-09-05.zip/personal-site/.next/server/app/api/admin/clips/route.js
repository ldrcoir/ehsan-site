var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/clips/route.js")
R.c("server/chunks/[root-of-the-server]__0a61ujp._.js")
R.c("server/chunks/_1xmxxdb._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_clips_route_actions_0fi0r4-.js")
R.m(7687)
module.exports=R.m(7687).exports
