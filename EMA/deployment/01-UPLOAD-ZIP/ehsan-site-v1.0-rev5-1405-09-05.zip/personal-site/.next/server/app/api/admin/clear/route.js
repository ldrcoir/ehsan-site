var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/clear/route.js")
R.c("server/chunks/[root-of-the-server]__12szab-._.js")
R.c("server/chunks/_17dcshd._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_clear_route_actions_0j8gc0m.js")
R.m(16195)
module.exports=R.m(16195).exports
