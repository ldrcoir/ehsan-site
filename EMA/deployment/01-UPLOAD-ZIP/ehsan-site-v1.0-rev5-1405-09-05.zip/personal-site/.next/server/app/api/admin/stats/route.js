var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/stats/route.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0j_y0c7._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_stats_route_actions_01pa690.js")
R.m(2068)
module.exports=R.m(2068).exports
