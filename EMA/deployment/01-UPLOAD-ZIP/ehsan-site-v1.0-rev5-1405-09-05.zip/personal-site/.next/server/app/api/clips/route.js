var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/clips/route.js")
R.c("server/chunks/[root-of-the-server]__0q192ww._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_clips_route_actions_0jzyj6j.js")
R.m(99627)
module.exports=R.m(99627).exports
