var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reply/route.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0g_f3lx._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reply_route_actions_1qo2gmd.js")
R.m(46465)
module.exports=R.m(46465).exports
