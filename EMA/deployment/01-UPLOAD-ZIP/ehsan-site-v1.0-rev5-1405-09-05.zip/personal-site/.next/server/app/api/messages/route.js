var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/messages/route.js")
R.c("server/chunks/[root-of-the-server]__12szab-._.js")
R.c("server/chunks/_1donioj._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_lib_access-auth_ts_0f7d_o5._.js")
R.c("server/chunks/_next-internal_server_app_api_messages_route_actions_08v1vp_.js")
R.m(36884)
module.exports=R.m(36884).exports
