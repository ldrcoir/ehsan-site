var R=require("../../chunks/[turbopack]_runtime.js")("server/app/rss.xml/route.js")
R.c("server/chunks/_1ix1b9o._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0k6aj8z._.js")
R.c("server/chunks/_next-internal_server_app_rss_xml_route_actions_104a-jb.js")
R.m(31782)
module.exports=R.m(31782).exports
