module.exports=[57408,e=>{e.v(s=>Promise.all(["server/chunks/[externals]_dns_1v_9f1c._.js"].map(s=>e.l(s))).then(()=>s(79594)))}];

//# sourceMappingURL=%5Bexternals%5D_dns_1dcnv4p._.js.map