module.exports=[85856,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_clips_route_actions_0fi0r4-.js.map