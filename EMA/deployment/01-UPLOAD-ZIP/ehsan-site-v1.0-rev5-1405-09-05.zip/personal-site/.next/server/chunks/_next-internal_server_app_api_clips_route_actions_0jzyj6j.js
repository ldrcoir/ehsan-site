module.exports=[86765,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clips_route_actions_0jzyj6j.js.map