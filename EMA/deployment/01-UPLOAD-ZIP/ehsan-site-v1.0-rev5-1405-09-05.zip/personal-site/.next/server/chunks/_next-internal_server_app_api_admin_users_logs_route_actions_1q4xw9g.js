module.exports=[90145,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_users_logs_route_actions_1q4xw9g.js.map