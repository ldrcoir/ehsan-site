module.exports=[16620,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_reply_route_actions_1qo2gmd.js.map