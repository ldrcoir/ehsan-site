module.exports=[78482,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_text_route_actions_1qb_02c.js.map