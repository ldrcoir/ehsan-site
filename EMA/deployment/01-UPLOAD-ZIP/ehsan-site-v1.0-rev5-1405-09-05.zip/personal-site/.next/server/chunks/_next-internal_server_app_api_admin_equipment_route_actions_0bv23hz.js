module.exports=[32795,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_equipment_route_actions_0bv23hz.js.map