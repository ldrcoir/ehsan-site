module.exports=[39258,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_security-dashboard_route_actions_0dq6576.js.map