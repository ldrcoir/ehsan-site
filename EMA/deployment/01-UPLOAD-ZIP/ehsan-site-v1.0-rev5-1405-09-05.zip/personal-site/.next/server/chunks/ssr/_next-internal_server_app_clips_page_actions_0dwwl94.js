module.exports=[11003,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_clips_page_actions_0dwwl94.js.map