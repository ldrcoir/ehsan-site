module.exports=[49083,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_nav_route_actions_1c-mij2.js.map