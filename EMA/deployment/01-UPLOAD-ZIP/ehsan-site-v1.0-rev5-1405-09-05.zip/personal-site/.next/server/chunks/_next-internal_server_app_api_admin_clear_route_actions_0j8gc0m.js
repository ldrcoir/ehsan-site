module.exports=[58669,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_clear_route_actions_0j8gc0m.js.map