# Personal Site — نسخه نهایی

## نصب (۳ دستور)

```bash
unzip site-final.zip
cd personal-site
sudo ./install.sh
```

## فضای لازم
حدود ۸۰۰ مگابایت

## دامنه‌ها
- https://ehsanmorad.ir
- https://ehsan-morad.ir
- https://ehsanmorad.id.ir

## ورود ادمین
- URL: `https://ehsanmorad.ir#admin`
- username: `admin`
- password: `admin123`
- ⚠️ از Settings رمز رو عوض کن!

## دستورات
```bash
systemctl status personal-site     # وضعیت
systemctl restart personal-site    # restart
systemctl stop personal-site       # توقف
journalctl -u personal-site -f     # لاگ سایت
sudo certbot renew                 # تمدید SSL
```

## نسخه
نهایی ۱.۰ — ۱۴۰۳
