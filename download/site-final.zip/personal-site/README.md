# Personal Site

## نصب (۳ دستور)

```bash
unzip site-final.zip
cd personal-site
sudo ./install.sh
```

## دامنه‌ها
- https://ehsanmorad.ir
- https://ehsan-morad.ir
- https://ehsanmorad.id.ir
