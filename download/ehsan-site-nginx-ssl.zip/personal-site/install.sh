#!/bin/bash
set -e
echo "=========================================="
echo "  نصب سایت با Nginx + SSL خودکار"
echo "  دامنه‌ها: ehsanmorad.ir, ehsan-morad.ir, ehsanmorad.id.ir"
echo "=========================================="
echo ""

echo "[1/8] بررسی Docker..."
if command -v docker &> /dev/null; then
    echo "  ✅ Docker نصبه"
else
    echo "  نصب Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    echo "  ✅ Docker نصب شد"
fi

echo ""
echo "[2/8] نصب Nginx و Certbot..."
if ! command -v nginx &> /dev/null; then
    apt update
    apt install -y nginx certbot python3-certbot-nginx
    systemctl enable nginx
    systemctl start nginx
    echo "  ✅ Nginx نصب شد"
else
    echo "  ✅ Nginx از قبل نصبه"
    apt install -y certbot python3-certbot-nginx 2>/dev/null || true
fi

echo ""
echo "[3/8] تنظیم فایروال..."
ufw allow 22/tcp 2>/dev/null || true
ufw allow 80/tcp 2>/dev/null || true
ufw allow 443/tcp 2>/dev/null || true
ufw allow 3000/tcp 2>/dev/null || true
echo "  ✅ فایروال ست شد"

echo ""
echo "[4/8] تولید SESSION_SECRET..."
SECRET=$(openssl rand -hex 32 || head -c 32 /dev/urandom | xxd -p | head -c 64)
if [ ! -f ".env" ]; then
    cat > .env << EOF
DATABASE_URL="file:./db/custom.db"
NODE_ENV="development"
PORT=3000
HOSTNAME="0.0.0.0"
SESSION_SECRET="$SECRET"
EOF
else
    if grep -q "SESSION_SECRET" .env; then
        sed -i "s/SESSION_SECRET=.*/SESSION_SECRET=\"$SECRET\"/g" .env
    else
        echo "SESSION_SECRET=\"$SECRET\"" >> .env
    fi
fi
echo "  ✅ SESSION_SECRET تولید شد"

echo ""
echo "[5/8] اجرای Docker (۳-۵ دقیقه)..."
docker compose up -d --build 2>&1 | tail -10
echo "  صبر ۶۰ ثانیه..."
sleep 60

echo ""
echo "[6/8] تنظیم Nginx..."
cp nginx-ehsanmorad.conf /etc/nginx/sites-available/nginx-ehsanmorad.conf 2>/dev/null || true
ln -sf /etc/nginx/sites-available/nginx-ehsanmorad.conf /etc/nginx/sites-enabled/nginx-ehsanmorad.conf 2>/dev/null || true
# حذف default اگه تداخل داره
rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true
nginx -t 2>&1 && systemctl reload nginx && echo "  ✅ Nginx تنظیم شد" || echo "  ⚠ خطای Nginx"

echo ""
echo "[7/8] تست سایت روی localhost..."
if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
    echo "  ✅ سایت بالا اومد"
else
    echo "  ⚠ سایت بالا نیومد — لاگ:"
    docker compose logs --tail 10
fi

echo ""
echo "[8/8] گرفتن SSL (Let's Encrypt)..."
echo "  نکته: DNS باید ست شده باشه، وگرنه SSL نمی‌گیره"
echo "  اگه DNS ست نشده، این مرحله رو skip کن"
echo ""
read -p "  آیا DNS ست شده؟ (y/n): " DNS_OK
if [ "$DNS_OK" = "y" ] || [ "$DNS_OK" = "Y" ]; then
    for domain in ehsanmorad.ir ehsan-morad.ir ehsanmorad.id.ir; do
        echo "  گرفتن SSL برای $domain..."
        certbot --nginx -d $domain -d www.$domain --non-interactive --agree-tos -m admin@$domain --redirect 2>&1 | tail -5 || echo "  ⚠ خطا برای $domain"
    done
    systemctl reload nginx
    echo "  ✅ SSL گرفته شد"
else
    echo "  ⚠ DNS ست نیست — SSL گرفته نشد"
    echo "  بعداً با این دستور SSL بگیر:"
    echo "    sudo certbot --nginx -d ehsanmorad.ir -d www.ehsanmorad.ir"
fi

echo ""
echo "=========================================="
echo "  ✅ نصب کامل شد!"
echo "=========================================="
echo ""
echo "  دامنه‌ها:"
echo "    https://ehsanmorad.ir"
echo "    https://ehsan-morad.ir"
echo "    https://ehsanmorad.id.ir"
echo ""
echo "  اگه DNS ست نشده، فعلاً روی:"
echo "    http://31.70.76.10:3000"
echo ""
echo "  ورود ادمین:"
echo "    https://ehsanmorad.ir#admin"
echo "    username: admin"
echo "    password: admin123"
echo "    ⚠️ از Settings رمز رو عوض کن!"
echo ""
echo "  دستورات:"
echo "    docker compose logs -f        # لاگ سایت"
echo "    sudo systemctl status nginx   # وضعیت Nginx"
echo "    sudo certbot renew            # تمدید SSL"
echo ""
echo "=========================================="
