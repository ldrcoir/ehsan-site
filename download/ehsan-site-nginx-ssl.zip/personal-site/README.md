# Personal Site

## نصب (۳ دستور)

```bash
unzip personal-site.zip
cd personal-site
sudo ./install.sh
```

## دامنه‌ها (با Nginx + SSL)

- https://ehsanmorad.ir
- https://ehsan-morad.ir
- https://ehsanmorad.id.ir

## ورود ادمین

- URL: `https://ehsanmorad.ir#admin`
- username: `admin`
- password: `admin123`
- ⚠️ از Settings رمز رو عوض کن!

## دستورات

```bash
docker compose logs -f            # لاگ سایت
sudo systemctl status nginx       # وضعیت Nginx
sudo certbot renew                # تمدید SSL
docker compose restart            # restart سایت
docker compose down               # توقف
```

## نکته

- Nginx روی پورت ۸۰/۴۴۳ (بدون تداخل)
- سایت روی پورت ۳۰۰۰ (داخل Docker)
- Nginx دامنه‌ها رو به سایت وصل می‌کنه
- SSL خودکار با Certbot
