# Personal Site V19.1

## Quick Start

```bash
# 1. Extract
unzip personal-site-v19.1.zip
cd personal-site-v19

# 2. Run with Docker
docker-compose up -d

# 3. View
open http://localhost:3000
```

## Admin Access

- URL: http://localhost:3000#admin (or Ctrl+Shift+A)
- Username: admin
- Password: admin123
- ⚠️ CHANGE PASSWORD IMMEDIATELY from Settings tab!

## User Login (for access-controlled users)

- URL: http://localhost:3000/user-login
- Admin can create users with time-based access from admin panel → Users tab

## Features

- Next.js 16 + TypeScript + Prisma + SQLite
- Matrix terminal theme (green on black)
- Signal Lab with oscilloscope + signal generator (AM/FM)
- AI chat with multiple providers (Z.ai, OpenAI, Anthropic, Groq, OpenRouter, Ollama)
- Admin panel with 9 tabs
- User management with time-based access (V19)
- 7 themes + theme builder
- 3 languages (EN, DE, FA)
- PWA, RSS, Sitemap
- Anti-theft (domain lock, watermark, devtools detection)

## Transfer to new VPS

```bash
# Old VPS:
docker cp personal-site:/app/db/custom.db ./backup.db
zip -r site-backup.zip personal-site-v19/ backup.db

# New VPS:
unzip site-backup.zip
cd personal-site-v19
docker-compose up -d
docker cp ../backup.db personal-site:/app/db/custom.db
docker-compose restart
```

## Version

V19.1 — 2026-09-03
