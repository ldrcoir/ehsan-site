"""
Seed the database with default content from content.ts.
Run: python3 scripts/seed_content.py
"""
import sqlite3
import json
from pathlib import Path

DB = Path("/home/z/my-project/db/custom.db")
CONTENT = Path("/home/z/my-project/src/lib/content.ts")

# Parse content.ts (simplified — we'll use hardcoded defaults for seeding)
# In production, the admin panel manages everything via API.

conn = sqlite3.connect(DB)
cur = conn.cursor()

# --- Seed default books ---
books = [
    ("b1", "Book Title One", "Buchtitel Eins", "عنوان کتاب اول", "2024",
     "Publisher Name", "Verlag", "ناشر",
     "A short description of what this book is about.",
     "Eine kurze Beschreibung des Buches.",
     "توضیح کوتاهی درباره‌ی موضوع کتاب."),
    ("b2", "Book Title Two", "Buchtitel Zwei", "عنوان کتاب دوم", "2023",
     "Another Publisher", "Anderer Verlag", "ناشر دیگر",
     "A short description of the second book.",
     "Kurze Beschreibung des zweiten Buches.",
     "توضیح کوتاه کتاب دوم."),
    ("b3", "Book Title Three", "Buchtitel Drei", "عنوان کتاب سوم", "2022",
     "Third Publisher", "Dritter Verlag", "ناشر سوم",
     "Another book description.",
     "Weitere Buchbeschreibung.",
     "توضیح کتاب دیگر."),
]

for b in books:
    cur.execute("""
        INSERT OR REPLACE INTO Book (id, titleEn, titleDe, titleFa, year,
            publisherEn, publisherDe, publisherFa, descEn, descDe, descFa,
            cover, link, "order", visible, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'linear-gradient(135deg,#003b00,#00ff41)', '#', ?, 1, datetime('now'), datetime('now'))
    """, (b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], books.index(b)))

# --- Seed default articles ---
articles = [
    ("a1", "Article Title One", "Artikeltitel Eins", "عنوان مقاله اول",
     "Journal / Blog Name", "Zeitschrift", "نام مجله",
     "2024-09", "Research Paper", "Forschungspapier", "مقاله پژوهشی",
     "Short summary of the article.", "Kurze Zusammenfassung.", "خلاصه کوتاه مقاله."),
    ("a2", "Article Title Two", "Artikeltitel Zwei", "عنوان مقاله دوم",
     "Another Venue", "Andere Publikation", "ناشر دیگر",
     "2024-04", "Tutorial", "Tutorial", "آموزش",
     "Brief summary of what this tutorial covers.", "Kurze Zusammenfassung des Tutorials.", "خلاصه آموزش."),
    ("a3", "Article Title Three", "Artikeltitel Drei", "عنوان مقاله سوم",
     "Blog Post", "Blogbeitrag", "پست وبلاگ",
     "2023-11", "Essay", "Essay", "مقاله",
     "Short description of the essay.", "Kurze Beschreibung.", "توضیح کوتاه."),
    ("a4", "Article Title Four", "Artikeltitel Vier", "عنوان مقاله چهارم",
     "Conference", "Konferenz", "کنفرانس",
     "2023-06", "Conference Paper", "Konferenzbeitrag", "مقاله کنفرانسی",
     "Brief summary of this conference paper.", "Kurze Zusammenfassung.", "خلاصه مقاله کنفرانس."),
]

for a in articles:
    cur.execute("""
        INSERT OR REPLACE INTO Article (id, titleEn, titleDe, titleFa,
            venueEn, venueDe, venueFa, date, typeEn, typeDe, typeFa,
            summaryEn, summaryDe, summaryFa, link, "order", visible, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '#', ?, 1, datetime('now'), datetime('now'))
    """, (a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], articles.index(a)))

# --- Seed default tutorials ---
tutorials = [
    ("t1", "Tutorial One — Intro", "Tutorial Eins", "آموزش اول — مقدمه",
     "12:34", "Beginner", "Anfänger", "مقدماتی",
     "Short description.", "Kurze Beschreibung.", "توضیح کوتاه.",
     "https://www.aparat.com/video/video/embed/videohash/example1/vframe"),
    ("t2", "Tutorial Two — Hands-On", "Tutorial Zwei", "آموزش دوم — عملی",
     "23:45", "Intermediate", "Fortgeschritten", "متوسط",
     "Short description.", "Kurze Beschreibung.", "توضیح کوتاه.",
     "https://www.aparat.com/video/video/embed/videohash/example2/vframe"),
    ("t3", "Tutorial Three — Deep Dive", "Tutorial Drei", "آموزش سوم — پیشرفته",
     "45:12", "Advanced", "Fortgeschritten", "پیشرفته",
     "Short description.", "Kurze Beschreibung.", "توضیح کوتاه.",
     "https://www.aparat.com/video/video/embed/videohash/example3/vframe"),
    ("t4", "Tutorial Four — Project", "Tutorial Vier", "آموزش چهارم — پروژه",
     "38:20", "Intermediate", "Fortgeschritten", "متوسط",
     "Short description.", "Kurze Beschreibung.", "توضیح کوتاه.",
     "https://www.aparat.com/video/video/embed/videohash/example4/vframe"),
]

for t in tutorials:
    cur.execute("""
        INSERT OR REPLACE INTO Tutorial (id, titleEn, titleDe, titleFa,
            duration, levelEn, levelDe, levelFa, descEn, descDe, descFa,
            embedUrl, platform, playlist, "order", visible, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aparat', NULL, ?, 1, datetime('now'), datetime('now'))
    """, (t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], tutorials.index(t)))

# --- Seed default skills ---
skills = [
    ("s1", "RF & Microwave", "RF & Mikrowelle", "RF و مایکروویو",
     "Antenna Design, EM Simulation (CST/HFSS), S-Parameters, Matching Networks, Waveguide, Phased Arrays"),
    ("s2", "AI / Machine Learning", "KI / Maschinelles Lernen", "هوش مصنوعی / یادگیری ماشین",
     "Python, PyTorch, TensorFlow, Signal Processing, Deep Learning, Scientific Computing"),
    ("s3", "Programming", "Programmierung", "برنامه‌نویسی",
     "Python, MATLAB, C/C++, JavaScript, Bash, LaTeX"),
    ("s4", "Writing & Translation", "Schreiben & Übersetzung", "نویسندگی و ترجمه",
     "Technical Writing, EN ↔ DE ↔ FA, Editing, Documentation, Blogging"),
]

for s in skills:
    cur.execute("""
        INSERT OR REPLACE INTO Skill (id, categoryEn, categoryDe, categoryFa, items,
            "order", visible, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))
    """, (s[0], s[1], s[2], s[3], s[4], skills.index(s)))

# --- Seed default AI instructions ---
instructions = [
    ("role", "Role",
     "You are the AI concierge on this personal portfolio website. You are NOT the site owner — you are the site's AI assistant. Your job is to welcome visitors, answer questions about the site's content, and encourage engagement.",
     0),
    ("personality", "Personality",
     "Be warm, curious, and slightly nerdy — like a knowledgeable friend giving a house tour. Keep responses SHORT: 2-4 sentences usually. End with a question when natural. Use light humor occasionally.",
     1),
    ("language", "Language Rule",
     "Respond in the same language the visitor uses. German → German. Persian → Persian. English → English. If mixed, match the dominant language.",
     2),
    ("goals", "Goals",
     "1. Make the visitor feel welcome. 2. Understand their interests (RF? AI? writing? tutorials?). 3. Recommend relevant books/articles/tutorials. 4. Invite their OPINION on the work. 5. Point to contact form for direct communication.",
     3),
    ("limits", "Limits",
     "Never claim to BE the site owner. Don't make up specific details about books/articles you don't know. Keep it conversational — no bullet lists unless asked. If visitor seems uninterested, back off gracefully.",
     4),
]

for inst in instructions:
    cur.execute("""
        INSERT OR REPLACE INTO AiInstruction (id, name, content, enabled, "order", createdAt, updatedAt)
        VALUES (?, ?, ?, 1, ?, datetime('now'), datetime('now'))
    """, (inst[0], inst[1], inst[2], inst[3]))

conn.commit()
conn.close()

print("✓ Content seeded to database")
print(f"  Books: {len(books)}")
print(f"  Articles: {len(articles)}")
print(f"  Tutorials: {len(tutorials)}")
print(f"  Skills: {len(skills)}")
print(f"  AI Instructions: {len(instructions)}")
