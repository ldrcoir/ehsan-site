"use client";

import { useEffect, useRef, useState } from "react";

type Waveform = "sine" | "square" | "triangle" | "sawtooth";

/**
 * RealSignalGenerator — Smooth, full-featured RF signal generator.
 *
 * Uses delta-time for frame-rate independent smooth animation.
 * AM/FM modulation actually works by modifying the carrier.
 */

const FREQ_RANGES = [
  { label: "Hz", min: 1, max: 999, mult: 1 },
  { label: "kHz", min: 1, max: 999, mult: 1000 },
  { label: "MHz", min: 1, max: 100, mult: 1000000 },
];

type OutputImpedance = "50Ω" | "600Ω" | "High-Z";
type Modulation = "NONE" | "AM" | "FM";

export default function RealSignalGenerator({
  waveform,
  frequency,
  amplitude,
  onWaveformChange,
  onFrequencyChange,
  onAmplitudeChange,
}: {
  waveform: Waveform;
  frequency: number;
  amplitude: number;
  onWaveformChange: (w: Waveform) => void;
  onFrequencyChange: (f: number) => void;
  onAmplitudeChange: (a: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef(0);
  const lastTimeRef = useRef(0);
  const phaseRef = useRef(0); // accumulated carrier phase (radians)
  const modPhaseRef = useRef(0); // accumulated modulation phase

  const [freqRange, setFreqRange] = useState(0);
  const [ampV, setAmpV] = useState(2.0);
  const [offset, setOffset] = useState(0);
  const [impedance, setImpedance] = useState<OutputImpedance>("50Ω");
  const [modulation, setModulation] = useState<Modulation>("NONE");
  const [modFreq, setModFreq] = useState(10);
  const [modDepth, setModDepth] = useState(0.5); // 0-1
  const [outputOn, setOutputOn] = useState(true);

  const actualFreq = frequency * FREQ_RANGES[freqRange].mult;

  // Compute waveform value at a given phase
  const waveAt = (phase: number, wf: Waveform, amp: number): number => {
    // Normalize phase to [0, 2π)
    const t = ((phase % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
    const peakV = amp * 5; // 0-1 → 0-5V peak
    switch (wf) {
      case "sine":
        return Math.sin(t) * peakV;
      case "square":
        return (t < Math.PI ? 1 : -1) * peakV;
      case "triangle":
        return (t < Math.PI
          ? -1 + (2 * t / Math.PI)
          : 3 - (2 * t / Math.PI)) * peakV;
      case "sawtooth":
        return ((t / Math.PI) - 1) * peakV;
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let w = 0, h = 0;
    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const draw = (now: number) => {
      rafRef.current = requestAnimationFrame(draw);

      // Delta time in seconds (clamp to avoid jumps)
      const dt = lastTimeRef.current === 0 ? 0.016 : Math.min((now - lastTimeRef.current) / 1000, 0.05);
      lastTimeRef.current = now;

      // Accumulate phases — this is what makes it smooth and frame-rate independent
      // For display, we use a visual frequency (scaled down for visibility)
      const visualFreq = Math.min(actualFreq, 50); // cap for display
      phaseRef.current += 2 * Math.PI * visualFreq * dt;
      modPhaseRef.current += 2 * Math.PI * modFreq * dt;

      const styles = getComputedStyle(document.documentElement);
      const bgColor = styles.getPropertyValue("--bg").trim() || "#000";
      const greenColor = styles.getPropertyValue("--green").trim() || "#00ff41";
      const greenBright = styles.getPropertyValue("--green-bright").trim() || "#39ff14";
      const textDim = styles.getPropertyValue("--text-dim").trim() || "#4a7a4a";
      const textFaint = styles.getPropertyValue("--text-faint").trim() || "#2a4a2a";

      // Clear
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, w, h);

      // Grid
      ctx.strokeStyle = `rgba(${hexToRgb(greenColor)}, 0.1)`;
      ctx.lineWidth = 1;
      for (let i = 0; i <= 8; i++) {
        const x = (i / 8) * w;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
      }
      for (let i = 0; i <= 4; i++) {
        const y = (i / 4) * h;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      }
      // Center line
      ctx.strokeStyle = `rgba(${hexToRgb(greenColor)}, 0.25)`;
      ctx.beginPath(); ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2); ctx.stroke();

      if (outputOn) {
        // Draw waveform — show 2 cycles across the width
        ctx.shadowColor = `rgba(${hexToRgb(greenColor)}, 0.6)`;
        ctx.shadowBlur = 6;
        ctx.strokeStyle = greenBright;
        ctx.lineWidth = 1.8;
        ctx.beginPath();

        const samples = w;
        const cyclesToShow = 2;

        for (let i = 0; i <= samples; i++) {
          const frac = i / samples;
          // Carrier phase: cyclesToShow full cycles across screen + time offset
          const carrierPhase = frac * 2 * Math.PI * cyclesToShow + phaseRef.current;

          let v: number;

          if (modulation === "AM") {
            // AM: amplitude varies with modulation signal
            // modSignal ranges from (1 - depth) to 1
            const modSignal = 1 - modDepth + modDepth * (0.5 + 0.5 * Math.sin(modPhaseRef.current));
            v = waveAt(carrierPhase, waveform, amplitude * modSignal);
          } else if (modulation === "FM") {
            // FM: frequency varies with modulation signal
            // We shift the carrier phase by the integral of the mod signal
            const modSignal = Math.sin(modPhaseRef.current);
            // Phase deviation = modDepth * maxDeviation * integral of modSignal
            // For simplicity, use phase shift proportional to modSignal
            const phaseShift = modDepth * 2 * Math.PI * modSignal;
            v = waveAt(carrierPhase + phaseShift, waveform, amplitude);
          } else {
            v = waveAt(carrierPhase, waveform, amplitude);
          }

          // Apply DC offset
          v += offset;

          // Map to screen (±10V → full height)
          const y = h / 2 - (v / 10) * (h / 2 - 8);
          if (i === 0) ctx.moveTo(i, y);
          else ctx.lineTo(i, y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0;

        // If modulation is on, also draw the modulating signal (faint, for reference)
        if (modulation !== "NONE") {
          ctx.strokeStyle = `rgba(${hexToRgb(greenColor)}, 0.3)`;
          ctx.lineWidth = 1;
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          for (let i = 0; i <= samples; i++) {
            const frac = i / samples;
            const modSignal = modulation === "AM"
              ? 1 - modDepth + modDepth * (0.5 + 0.5 * Math.sin(modPhaseRef.current + frac * 2 * Math.PI * cyclesToShow * (modFreq / visualFreq)))
              : Math.sin(modPhaseRef.current + frac * 2 * Math.PI * cyclesToShow * (modFreq / visualFreq));
            const modV = modSignal * 3; // scale for display
            const y = h / 2 - (modV / 10) * (h / 2 - 8);
            if (i === 0) ctx.moveTo(i, y);
            else ctx.lineTo(i, y);
          }
          ctx.stroke();
          ctx.setLineDash([]);
        }
      } else {
        // Output off — flat line
        ctx.strokeStyle = `rgba(${hexToRgb(textFaint)}, 0.5)`;
        ctx.beginPath();
        ctx.moveTo(0, h / 2);
        ctx.lineTo(w, h / 2);
        ctx.stroke();
      }

      // Labels
      ctx.fillStyle = textDim;
      ctx.font = "8px monospace";
      ctx.fillText("GEN · OUTPUT", 6, 12);

      const freqLabel = actualFreq >= 1000000
        ? `${(actualFreq / 1000000).toFixed(2)} MHz`
        : actualFreq >= 1000
        ? `${(actualFreq / 1000).toFixed(2)} kHz`
        : `${actualFreq.toFixed(1)} Hz`;

      const modLabel = modulation === "NONE" ? "" : ` · ${modulation} ${modFreq.toFixed(0)}Hz ${Math.round(modDepth * 100)}%`;

      ctx.fillStyle = outputOn ? greenBright : textFaint;
      ctx.fillText(
        `${waveform.toUpperCase()} · ${freqLabel} · ${ampV.toFixed(2)}Vpp · ${offset.toFixed(2)}V DC${modLabel}`,
        6, h - 6
      );

      ctx.fillStyle = outputOn ? greenBright : "#ff0040";
      ctx.fillText(outputOn ? "● OUTPUT" : "○ OFF", w - 60, 12);
    };

    if (!reduce) {
      rafRef.current = requestAnimationFrame(draw);
    } else {
      draw(0);
      cancelAnimationFrame(rafRef.current);
    }

    return () => {
      cancelAnimationFrame(rafRef.current);
      ro.disconnect();
    };
  }, [waveform, frequency, ampV, offset, impedance, modulation, modFreq, modDepth, outputOn, freqRange, amplitude]);

  const waveforms: { id: Waveform; label: string }[] = [
    { id: "sine", label: "∿ sine" },
    { id: "square", label: "⊓ sqr" },
    { id: "triangle", label: "△ tri" },
    { id: "sawtooth", label: "⩘ saw" },
  ];

  return (
    <div className="signal-device">
      <div className="signal-device-bar">
        <span className="signal-device-name">SIGNAL GENERATOR</span>
        <span className="signal-device-model">Keysight 33600A · 80MHz</span>
      </div>
      <div className="signal-device-screen" style={{ height: 100 }}>
        <canvas ref={canvasRef} style={{ width: "100%", height: "100%" }} />
      </div>
      <div className="osc-controls">
        {/* Waveform */}
        <div className="osc-control-group">
          <div className="osc-control-label"><span>WAVEFORM</span></div>
          <div className="osc-button-row">
            {waveforms.map(w => (
              <button key={w.id} className={`signal-waveform-btn ${waveform === w.id ? "active" : ""}`} onClick={() => onWaveformChange(w.id)}>
                {w.label}
              </button>
            ))}
          </div>
        </div>

        {/* Freq Range */}
        <div className="osc-control-group">
          <div className="osc-control-label">
            <span>FREQ RANGE</span>
            <span className="value">×{FREQ_RANGES[freqRange].label}</span>
          </div>
          <div className="osc-button-row">
            {FREQ_RANGES.map((r, i) => (
              <button key={r.label} className={`signal-waveform-btn ${freqRange === i ? "active" : ""}`}
                onClick={() => { setFreqRange(i); onFrequencyChange(Math.min(frequency, r.max)); }}>
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Frequency */}
        <div className="osc-control-group">
          <div className="osc-control-label">
            <span>FREQUENCY</span>
            <span className="value">{frequency.toFixed(1)} {FREQ_RANGES[freqRange].label}</span>
          </div>
          <input type="range" className="signal-control-input"
            min={FREQ_RANGES[freqRange].min} max={FREQ_RANGES[freqRange].max} step="0.1"
            value={frequency} onChange={(e) => onFrequencyChange(parseFloat(e.target.value))} />
        </div>

        {/* Amplitude */}
        <div className="osc-control-group">
          <div className="osc-control-label">
            <span>AMPLITUDE (Vpp)</span>
            <span className="value">{ampV.toFixed(2)}V</span>
          </div>
          <input type="range" className="signal-control-input" min="0.01" max="10" step="0.1"
            value={ampV} onChange={(e) => { setAmpV(parseFloat(e.target.value)); onAmplitudeChange(parseFloat(e.target.value) / 10); }} />
        </div>

        {/* DC Offset */}
        <div className="osc-control-group">
          <div className="osc-control-label">
            <span>DC OFFSET</span>
            <span className="value">{offset.toFixed(2)}V</span>
          </div>
          <input type="range" className="signal-control-input" min="-5" max="5" step="0.1"
            value={offset} onChange={(e) => setOffset(parseFloat(e.target.value))} />
        </div>

        {/* Impedance */}
        <div className="osc-control-group">
          <div className="osc-control-label"><span>IMPEDANCE</span></div>
          <div className="osc-button-row">
            {(["50Ω", "600Ω", "High-Z"] as OutputImpedance[]).map(z => (
              <button key={z} className={`signal-waveform-btn ${impedance === z ? "active" : ""}`} onClick={() => setImpedance(z)}>
                {z}
              </button>
            ))}
          </div>
        </div>

        {/* Modulation */}
        <div className="osc-control-group">
          <div className="osc-control-label"><span>MODULATION</span></div>
          <div className="osc-button-row">
            {(["NONE", "AM", "FM"] as Modulation[]).map(m => (
              <button key={m} className={`signal-waveform-btn ${modulation === m ? "active" : ""}`} onClick={() => setModulation(m)}>
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Mod params */}
        {modulation !== "NONE" && (
          <>
            <div className="osc-control-group">
              <div className="osc-control-label">
                <span>MOD FREQ</span>
                <span className="value">{modFreq.toFixed(1)}Hz</span>
              </div>
              <input type="range" className="signal-control-input" min="1" max="100" step="0.5"
                value={modFreq} onChange={(e) => setModFreq(parseFloat(e.target.value))} />
            </div>
            <div className="osc-control-group">
              <div className="osc-control-label">
                <span>MOD DEPTH</span>
                <span className="value">{Math.round(modDepth * 100)}%</span>
              </div>
              <input type="range" className="signal-control-input" min="0" max="1" step="0.05"
                value={modDepth} onChange={(e) => setModDepth(parseFloat(e.target.value))} />
            </div>
          </>
        )}

        {/* Output */}
        <div className="osc-control-group">
          <div className="osc-control-label"><span>OUTPUT</span></div>
          <button className={`signal-waveform-btn ${outputOn ? "active" : ""}`}
            onClick={() => setOutputOn(!outputOn)}
            style={{ width: "100%", background: outputOn ? "var(--green)" : "var(--red)", color: "#000" }}>
            {outputOn ? "● OUTPUT ON" : "○ OUTPUT OFF"}
          </button>
        </div>
      </div>
    </div>
  );
}

function hexToRgb(hex: string): string {
  const h = hex.replace("#", "").trim();
  if (h.length !== 6) return "0, 255, 65";
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `${r}, ${g}, ${b}`;
}
