"use client";

import { useEffect, useState } from "react";

/**
 * ContentManager — Admin panel component for managing site content.
 * Supports: books, articles, tutorials, skills, aiInstructions.
 * CRUD: create, edit, delete, toggle visibility, bulk import.
 */

type ContentType = "book" | "article" | "tutorial" | "skill" | "aiInstruction";

interface Item {
  id: string;
  [key: string]: any;
}

export default function ContentManager({ password, lang }: { password: string; lang: string }) {
  const [activeType, setActiveType] = useState<ContentType>("tutorial");
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Item | null>(null);
  const [showBulk, setShowBulk] = useState(false);
  const [bulkText, setBulkText] = useState("");

  const typeLabels: Record<ContentType, { en: string; fa: string; de: string }> = {
    book: { en: "Books", fa: "کتاب‌ها", de: "Bücher" },
    article: { en: "Articles", fa: "مقالات", de: "Artikel" },
    tutorial: { en: "Tutorials", fa: "آموزش‌ها", de: "Tutorials" },
    skill: { en: "Skills", fa: "مهارت‌ها", de: "Fähigkeiten" },
    aiInstruction: { en: "AI Rules", fa: "قواعد AI", de: "KI-Regeln" },
  };

  useEffect(() => {
    loadItems();
  }, [activeType]);

  const loadItems = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/content?password=${password}&type=${activeType}`);
      const data = await res.json();
      if (data.ok) {
        setItems(data.items || []);
      }
    } catch {}
    setLoading(false);
  };

  const saveItem = async (item: Item) => {
    const isNew = !item.id;
    const action = isNew ? "create" : "update";
    const payload: any = { password, type: activeType, action };
    if (!isNew) payload.id = item.id;
    payload.data = { ...item };
    delete payload.data.id;
    delete payload.data.createdAt;
    delete payload.data.updatedAt;

    try {
      const res = await fetch("/api/admin/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.ok) {
        setEditing(null);
        loadItems();
      }
    } catch {}
  };

  const deleteItem = async (id: string) => {
    if (!confirm("Delete this item?")) return;
    try {
      await fetch("/api/admin/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, type: activeType, action: "delete", id }),
      });
      loadItems();
    } catch {}
  };

  const toggleItem = async (id: string) => {
    try {
      await fetch("/api/admin/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, type: activeType, action: "toggle", id }),
      });
      loadItems();
    } catch {}
  };

  const bulkImport = async () => {
    try {
      const parsed = JSON.parse(bulkText);
      if (!Array.isArray(parsed)) {
        alert("Must be a JSON array of items");
        return;
      }
      const res = await fetch("/api/admin/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, type: activeType, action: "bulk_import", items: parsed }),
      });
      const data = await res.json();
      if (data.ok) {
        alert(`Imported ${data.created} of ${data.total} items`);
        setBulkText("");
        setShowBulk(false);
        loadItems();
      }
    } catch {
      alert("Invalid JSON");
    }
  };

  const getEmptyItem = (): Item => {
    switch (activeType) {
      case "book":
        return { titleEn: "", titleDe: "", titleFa: "", year: "2025", publisherEn: "", publisherDe: "", publisherFa: "", descEn: "", descDe: "", descFa: "", cover: "linear-gradient(135deg,#003b00,#00ff41)", link: "#", visible: true, order: 0 };
      case "article":
        return { titleEn: "", titleDe: "", titleFa: "", venueEn: "", venueDe: "", venueFa: "", date: "2025-01", typeEn: "Article", typeDe: "", typeFa: "", summaryEn: "", summaryDe: "", summaryFa: "", link: "#", visible: true, order: 0 };
      case "tutorial":
        return { titleEn: "", titleDe: "", titleFa: "", duration: "00:00", levelEn: "Beginner", levelDe: "", levelFa: "", descEn: "", descDe: "", descFa: "", embedUrl: "", platform: "aparat", playlist: "", visible: true, order: 0 };
      case "skill":
        return { categoryEn: "", categoryDe: "", categoryFa: "", items: "", visible: true, order: 0 };
      case "aiInstruction":
        return { name: "", content: "", enabled: true, order: 0 };
      default:
        return {};
    }
  };

  const fields: Record<ContentType, { key: string; label: string; type: string }[]> = {
    book: [
      { key: "titleEn", label: "Title (EN)", type: "text" },
      { key: "titleFa", label: "Title (FA)", type: "text" },
      { key: "titleDe", label: "Title (DE)", type: "text" },
      { key: "year", label: "Year", type: "text" },
      { key: "publisherEn", label: "Publisher (EN)", type: "text" },
      { key: "descEn", label: "Description (EN)", type: "textarea" },
      { key: "descFa", label: "Description (FA)", type: "textarea" },
      { key: "cover", label: "Cover (CSS gradient)", type: "text" },
      { key: "link", label: "Link", type: "text" },
      { key: "order", label: "Order", type: "number" },
    ],
    article: [
      { key: "titleEn", label: "Title (EN)", type: "text" },
      { key: "titleFa", label: "Title (FA)", type: "text" },
      { key: "venueEn", label: "Venue (EN)", type: "text" },
      { key: "date", label: "Date (YYYY-MM)", type: "text" },
      { key: "typeEn", label: "Type (EN)", type: "text" },
      { key: "summaryEn", label: "Summary (EN)", type: "textarea" },
      { key: "summaryFa", label: "Summary (FA)", type: "textarea" },
      { key: "link", label: "Link", type: "text" },
      { key: "order", label: "Order", type: "number" },
    ],
    tutorial: [
      { key: "titleEn", label: "Title (EN)", type: "text" },
      { key: "titleFa", label: "Title (FA)", type: "text" },
      { key: "duration", label: "Duration (mm:ss)", type: "text" },
      { key: "levelEn", label: "Level (EN)", type: "text" },
      { key: "embedUrl", label: "Embed URL", type: "text" },
      { key: "playlist", label: "Playlist (optional)", type: "text" },
      { key: "descEn", label: "Description (EN)", type: "textarea" },
      { key: "descFa", label: "Description (FA)", type: "textarea" },
      { key: "order", label: "Order", type: "number" },
    ],
    skill: [
      { key: "categoryEn", label: "Category (EN)", type: "text" },
      { key: "categoryFa", label: "Category (FA)", type: "text" },
      { key: "items", label: "Items (comma-separated)", type: "textarea" },
      { key: "order", label: "Order", type: "number" },
    ],
    aiInstruction: [
      { key: "name", label: "Name", type: "text" },
      { key: "content", label: "Instruction Content", type: "textarea" },
      { key: "order", label: "Order", type: "number" },
    ],
  };

  const L = typeLabels[activeType];
  const label = lang === "fa" ? L.fa : lang === "de" ? L.de : L.en;

  return (
    <div>
      {/* Type selector */}
      <div className="admin-tabs">
        {(Object.keys(typeLabels) as ContentType[]).map(t => {
          const tl = typeLabels[t];
          const tLabel = lang === "fa" ? tl.fa : lang === "de" ? tl.de : tl.en;
          return (
            <button
              key={t}
              className={`admin-tab ${activeType === t ? "active" : ""}`}
              onClick={() => { setActiveType(t); setEditing(null); }}
            >
              {tLabel}
            </button>
          );
        })}
      </div>

      {/* Actions */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
        <button className="btn btn-primary btn-sm" onClick={() => setEditing(getEmptyItem())}>
          + {lang === "fa" ? "افزودن" : "add new"}
        </button>
        <button className="btn btn-ghost btn-sm" onClick={() => setShowBulk(!showBulk)}>
          {lang === "fa" ? "وارد کردن انبوه" : "bulk import (JSON)"}
        </button>
        <span style={{ color: "var(--text-dim)", fontSize: "0.78rem", alignSelf: "center" }}>
          {items.length} {lang === "fa" ? "آیتم" : "items"}
        </span>
      </div>

      {/* Bulk import */}
      {showBulk && (
        <div className="admin-reply-box" style={{ marginBottom: 16 }}>
          <label>
            {lang === "fa"
              ? "JSON آرایه‌ای از آیتم‌ها. مثال برای آموزش‌ها:"
              : "JSON array of items. Example for tutorials:"}
          </label>
          <textarea
            value={bulkText}
            onChange={(e) => setBulkText(e.target.value)}
            placeholder={`[\n  {\n    "titleEn": "Tutorial 1",\n    "embedUrl": "https://www.aparat.com/video/video/embed/videohash/XXXX/vframe",\n    "duration": "10:00",\n    "levelEn": "Beginner"\n  }\n]`}
            rows={8}
            style={{ width: "100%", fontFamily: "monospace", fontSize: "0.8rem" }}
          />
          <button className="btn btn-primary btn-sm" onClick={bulkImport} style={{ marginTop: 8 }}>
            {lang === "fa" ? "وارد کردن" : "import"}
          </button>
        </div>
      )}

      {/* Edit form */}
      {editing && (
        <div className="admin-reply-box" style={{ marginBottom: 16 }}>
          <label style={{ color: "var(--green-bright)", fontSize: "0.85rem" }}>
            {editing.id ? (lang === "fa" ? "ویرایش" : "edit") : (lang === "fa" ? "ایجاد" : "create")} {label}
          </label>
          {fields[activeType].map(f => (
            <div key={f.key} style={{ marginBottom: 8 }}>
              <label style={{ fontSize: "0.72rem", color: "var(--text-dim)" }}>{f.label}</label>
              {f.type === "textarea" ? (
                <textarea
                  value={editing[f.key] || ""}
                  onChange={(e) => setEditing({ ...editing, [f.key]: e.target.value })}
                  rows={2}
                  style={{ width: "100%", background: "var(--bg)", border: "1px solid var(--border)", color: "var(--green-bright)", fontFamily: "var(--font-mono)", fontSize: "0.8rem", padding: "6px" }}
                />
              ) : (
                <input
                  type={f.type === "number" ? "number" : "text"}
                  value={editing[f.key] || ""}
                  onChange={(e) => setEditing({ ...editing, [f.key]: f.type === "number" ? parseInt(e.target.value) || 0 : e.target.value })}
                  style={{ width: "100%", background: "var(--bg)", border: "1px solid var(--border)", color: "var(--green-bright)", fontFamily: "var(--font-mono)", fontSize: "0.8rem", padding: "6px" }}
                />
              )}
            </div>
          ))}
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button className="btn btn-primary btn-sm" onClick={() => saveItem(editing)}>
              {lang === "fa" ? "ذخیره" : "save"}
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => setEditing(null)}>
              {lang === "fa" ? "انصراف" : "cancel"}
            </button>
          </div>
        </div>
      )}

      {/* Items list */}
      {loading ? (
        <p style={{ color: "var(--text-dim)", textAlign: "center", padding: 20 }}>loading...</p>
      ) : items.length === 0 ? (
        <p style={{ color: "var(--text-dim)", textAlign: "center", padding: 20 }}>
          {lang === "fa" ? "هنوز آیتمی نیست." : "No items yet."}
        </p>
      ) : (
        <div className="admin-messages">
          {items.map(item => (
            <div key={item.id} className="admin-message">
              <div className="admin-message-head">
                <span>
                  {item.titleEn || item.name || item.categoryEn || `#${item.id.slice(-6)}`}
                </span>
                <span>
                  {item.visible === false || item.enabled === false ? "🔴 " : "🟢 "}
                  {item.year || item.date || item.duration || ""}
                </span>
              </div>
              <div className="admin-message-text" style={{ fontSize: "0.78rem" }}>
                {item.embedUrl && <div>URL: {item.embedUrl.slice(0, 60)}...</div>}
                {item.items && <div>Items: {item.items.slice(0, 80)}...</div>}
                {item.content && <div>{item.content.slice(0, 100)}...</div>}
                {item.descEn && <div>{item.descEn.slice(0, 100)}</div>}
              </div>
              <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                <button className="btn btn-ghost btn-sm" onClick={() => setEditing({ ...item })}>
                  {lang === "fa" ? "ویرایش" : "edit"}
                </button>
                <button className="btn btn-ghost btn-sm" onClick={() => toggleItem(item.id)}>
                  {item.visible === false || item.enabled === false
                    ? (lang === "fa" ? "فعال" : "show")
                    : (lang === "fa" ? "مخفی" : "hide")}
                </button>
                <button className="btn btn-ghost btn-sm" onClick={() => deleteItem(item.id)} style={{ color: "var(--red)" }}>
                  {lang === "fa" ? "حذف" : "delete"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
