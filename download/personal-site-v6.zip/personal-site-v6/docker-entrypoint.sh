#!/bin/bash
# ============================================================================
#  docker-entrypoint.sh — runs on container start
#  1. Push Prisma schema to DB (creates tables if needed)
#  2. Seed default content if DB is empty
#  3. Start the Next.js dev server
# ============================================================================

set -e

echo "=========================================="
echo "  Personal Site — Docker Starting..."
echo "=========================================="
echo ""

# Step 1: Push database schema
echo "[1/3] Pushing database schema..."
bunx prisma db push --accept-data-loss 2>&1 || true
echo "  ✓ Database schema ready"
echo ""

# Step 2: Seed default content if empty
echo "[2/3] Checking content..."
python3 scripts/seed_content.py 2>&1 || echo "  ⚠ Seed skipped (python3 not available or already seeded)"
echo ""

# Step 3: Start dev server
echo "[3/3] Starting Next.js dev server..."
echo "  → http://localhost:3000"
echo ""
exec bun run dev --host 0.0.0.0
