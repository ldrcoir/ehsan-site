# Personal Site — EhsanMorad

## نصب سریع (۳ قدم)

```bash
# ۱. Extract
unzip EhsanMorad-FINAL.zip
cd personal-site

# ۲. اجرا
docker-compose up -d --build

# ۳. صبر ۶۰ ثانیه، بعد تست
curl http://localhost:3000/
# باید HTTP 200 بده
```

## ورود ادمین

- URL: `http://YOUR_IP:3000#admin` (یا `Ctrl+Shift+A`)
- username: `admin`
- password: `admin123`
- ⚠️ حتماً از Settings رمز رو عوض کن!

## دامنه‌ها (از قبل ست شدن)

- `ehsanmorad.ir`
- `ehsan-morad.ir`
- `ehsanmorad.id.ir`
- `31.70.76.10` (VPS IP)

## اگه Caddy خواستی (اختیاری)

```bash
sudo apt install caddy
sudo cp Caddyfile /etc/caddy/Caddyfile
sudo systemctl restart caddy
```

نکته: اگه Nginx نصبه، Caddy نصب نکن.

## دستورات مفید

```bash
docker-compose logs -f          # لاگ
docker-compose restart          # restart
docker-compose down             # توقف
docker-compose up -d --build    # بازسازی
```

## نسخه
V19.4 — 2026-09-12
