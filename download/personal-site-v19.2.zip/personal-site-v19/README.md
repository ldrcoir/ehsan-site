# Personal Site

A full-featured personal portfolio website with terminal/RF theme.

## Quick Start

```bash
# 1. Extract
unzip personal-site-v19.2.zip
cd personal-site-v19

# 2. Run with Docker
docker-compose up -d

# 3. View in browser
# Site will be at http://localhost:3000
```

## First Time Setup

### 1. Change Admin Password (IMPORTANT!)

Default credentials:
- URL: http://localhost:3000#admin (or press Ctrl+Shift+A)
- Username: `admin`
- Password: `admin123`

⚠️ **Change the password immediately** from Settings tab in admin panel.

### 2. Add Your Domain

After deploying to your VPS with your domain, edit these files and add your domain:

**`src/app/page.tsx`** — find `authorizedDomains` array:
```typescript
const authorizedDomains = [
  "localhost",
  "127.0.0.1",
  "yourdomain.com",  // ← add your domain here
];
```

**`src/lib/canvas-protect.ts`** — find `AUTHORIZED_DOMAINS` array:
```typescript
const AUTHORIZED_DOMAINS = [
  "localhost",
  "127.0.0.1",
  "yourdomain.com",  // ← add your domain here
];
```

Then rebuild: `docker-compose up -d --build`

### 3. Personalize Your Site

Edit `src/lib/content.ts`:
- `handle` — your username/handle
- `fullName` — your name (in en/de/fa)
- `tagline` — your tagline
- `email` — your contact email
- `adminUsername` / `adminPassword` — admin credentials

Or use the admin panel (recommended) — all content is editable from there:
- Content tab — books, articles, tutorials, skills, equipment
- Text tab — 36 editable site texts
- Nav tab — navigation menu
- Themes tab — custom theme builder

### 4. Configure .env

The `.env` file is pre-configured for Docker. To customize:

```bash
# Edit .env
nano .env

# Key settings:
DATABASE_URL="file:./db/custom.db"
NODE_ENV="production"
PORT=3000
HOSTNAME="0.0.0.0"
SESSION_SECRET="change-this-to-a-random-secret"  # ← CHANGE THIS!

# Optional AI providers (leave empty for default ):
# OPENAI_API_KEY=""
# ANTHROPIC_API_KEY=""
# GROQ_API_KEY=""
# OPENROUTER_API_KEY=""
```

Then: `docker-compose up -d --build`

## User Login (Access Control)

Admin can create users with time-based access:

- URL: http://localhost:3000/user-login
- Admin → Users tab → New User
- Set allowed hours, days, expiry date
- Users can only access during their allowed time window

## Features

- Next.js 16 + TypeScript + Prisma + SQLite
- Matrix terminal theme (green on black)
- Signal Lab with oscilloscope + signal generator (AM/FM)
- AI chat with multiple providers
- Admin panel with 9 tabs
- User management with time-based access
- 7 themes + theme builder
- 3 languages (EN, DE, FA)
- PWA, RSS, Sitemap
- Anti-theft (domain lock, watermark, devtools detection)

## Transfer to New VPS

```bash
# On old VPS:
docker cp personal-site:/app/db/custom.db ./backup.db
tar -czf site-backup.tar.gz personal-site-v19/ backup.db

# On new VPS:
tar -xzf site-backup.tar.gz
cd personal-site-v19
docker-compose up -d
docker cp ../backup.db personal-site:/app/db/custom.db
docker-compose restart

# Remember to update your domain in:
# - src/app/page.tsx (authorizedDomains)
# - src/lib/canvas-protect.ts (AUTHORIZED_DOMAINS)
docker-compose up -d --build
```

## Project Structure

```
personal-site-v19/
├── src/
│   ├── app/
│   │   ├── page.tsx              # Main page
│   │   ├── layout.tsx            # HTML shell + viewport
│   │   ├── user-login/           # User login page
│   │   ├── user-dashboard/       # User dashboard
│   │   └── api/                  # API routes (25+)
│   ├── components/               # React components (21)
│   └── lib/                      # Utilities (auth, db, security, etc.)
├── prisma/
│   └── schema.prisma             # Database models (25+)
├── scripts/                      # Seed scripts + build helpers
├── public/                       # Static assets
├── db/                           # SQLite database
├── Dockerfile
├── docker-compose.yml
├── docker-entrypoint.sh
├── .env
└── README.md                     # This file
```

## Version

V19.2 — 2026-09-03

## Support

All source code has Persian line-by-line comments for easy understanding.
See `FULL_TUTORIAL_FA_V19.2.docx` for a complete 12-chapter tutorial in Persian.
