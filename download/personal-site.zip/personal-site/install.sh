#!/bin/bash
set -e
echo "=========================================="
echo "  نصب خودکار سایت"
echo "=========================================="
echo ""

echo "[1/6] بررسی Docker..."
if command -v docker &> /dev/null; then
    echo "  ✅ Docker از قبل نصبه"
else
    echo "  در حال نصب Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    echo "  ✅ Docker نصب شد"
fi

echo ""
echo "[2/6] تنظیم فایروال..."
if ! command -v ufw &> /dev/null; then
    apt update && apt install -y ufw 2>/dev/null || true
fi
ufw allow 22/tcp 2>/dev/null || true
ufw allow 80/tcp 2>/dev/null || true
ufw allow 443/tcp 2>/dev/null || true
ufw allow 3000/tcp 2>/dev/null || true
echo "  ✅ فایروال ست شد"

echo ""
echo "[3/6] تولید SESSION_SECRET..."
SECRET=$(openssl rand -hex 32 || head -c 32 /dev/urandom | xxd -p | head -c 64)
if [ ! -f ".env" ]; then
    cat > .env << EOF
DATABASE_URL="file:./db/custom.db"
NODE_ENV="development"
PORT=3000
HOSTNAME="0.0.0.0"
SESSION_SECRET="$SECRET"
EOF
else
    if grep -q "SESSION_SECRET" .env; then
        sed -i "s/SESSION_SECRET=.*/SESSION_SECRET=\"$SECRET\"/g" .env
    else
        echo "SESSION_SECRET=\"$SECRET\"" >> .env
    fi
fi
echo "  ✅ SESSION_SECRET تولید شد"

echo ""
echo "[4/6] اجرای Docker (۳-۵ دقیقه)..."
echo ""
docker compose up -d --build 2>&1 | tail -20

echo ""
echo "[5/6] صبر ۹۰ ثانیه..."
sleep 90

echo ""
echo "[6/6] تست سایت..."
if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
    echo "  ✅ سایت بالا اومد!"
    SUCCESS=true
else
    echo "  ⚠ ۳۰ ثانیه دیگه صبر..."
    sleep 30
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
        echo "  ✅ سایت بالا اومد!"
        SUCCESS=true
    else
        echo "  ❌ سایت بالا نیومد. لاگ:"
        docker compose logs --tail 30
        SUCCESS=false
    fi
fi

echo ""
echo "=========================================="
if [ "$SUCCESS" = "true" ]; then
    echo "  ✅ نصب کامل شد!"
else
    echo "  ⚠ نصب انجام شد ولی سایت بالا نیومد"
fi
echo "=========================================="
IP=$(curl -s ifconfig.me 2>/dev/null || echo "YOUR_IP")
echo ""
echo "  آدرس سایت: http://$IP:3000"
echo "  ورود ادمین: http://$IP:3000#admin"
echo "  username: admin"
echo "  password: admin123"
echo "  ⚠️ حتماً از Settings رمز رو عوض کن!"
echo ""
echo "  دستورات:"
echo "    docker compose logs -f     # لاگ"
echo "    docker compose restart    # restart"
echo "    docker compose down       # توقف"
echo ""
echo "=========================================="
