#!/bin/bash
set -e
echo "=========================================="
echo "  نصب خودکار سایت با دامنه"
echo "  دامنه‌ها: ehsanmorad.ir, ehsan-morad.ir, ehsanmorad.id.ir"
echo "=========================================="
echo ""

echo "[1/6] بررسی Docker..."
if command -v docker &> /dev/null; then
    echo "  ✅ Docker از قبل نصبه"
else
    echo "  در حال نصب Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    echo "  ✅ Docker نصب شد"
fi

echo ""
echo "[2/6] تنظیم فایروال..."
if ! command -v ufw &> /dev/null; then
    apt update && apt install -y ufw 2>/dev/null || true
fi
ufw allow 22/tcp 2>/dev/null || true
ufw allow 80/tcp 2>/dev/null || true
ufw allow 443/tcp 2>/dev/null || true
echo "  ✅ فایروال ست شد (پورت ۲۲، ۸۰، ۴۴۳)"

echo ""
echo "[3/6] تولید SESSION_SECRET..."
SECRET=$(openssl rand -hex 32 || head -c 32 /dev/urandom | xxd -p | head -c 64)
if [ ! -f ".env" ]; then
    cat > .env << EOF
DATABASE_URL="file:./db/custom.db"
NODE_ENV="development"
PORT=3000
HOSTNAME="0.0.0.0"
SESSION_SECRET="$SECRET"
EOF
else
    if grep -q "SESSION_SECRET" .env; then
        sed -i "s/SESSION_SECRET=.*/SESSION_SECRET=\"$SECRET\"/g" .env
    else
        echo "SESSION_SECRET=\"$SECRET\"" >> .env
    fi
fi
echo "  ✅ SESSION_SECRET تولید شد"

echo ""
echo "[4/6] اجرای Docker (سایت + Caddy)..."
echo "  (دفعه اول ۳-۵ دقیقه — داره دانلود می‌کنه)"
echo ""
docker compose up -d --build 2>&1 | tail -20

echo ""
echo "[5/6] صبر ۱۲۰ ثانیه (Caddy داره SSL می‌گیره)..."
sleep 120

echo ""
echo "[6/6] تست سایت..."

# تست روی localhost:3000 (سایت)
if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
    echo "  ✅ سایت روی localhost بالا اومد"
    SUCCESS=true
else
    echo "  ⚠ سایت روی localhost بالا نیومد"
    SUCCESS=false
fi

# تست روی دامنه‌ها (اگه DNS ست شده)
echo ""
echo "  تست دامنه‌ها:"
for domain in ehsanmorad.ir ehsan-morad.ir ehsanmorad.id.ir; do
    if curl -s -o /dev/null -w "%{http_code}" --max-time 10 "https://$domain/" 2>/dev/null | grep -q "200\|301\|302"; then
        echo "    ✅ https://$domain کار می‌کنه"
    else
        echo "    ⚠ https://$domain هنوز کار نمی‌کنه (DNS یا SSL)"
    fi
done

echo ""
echo "=========================================="
if [ "$SUCCESS" = "true" ]; then
    echo "  ✅ نصب کامل شد!"
else
    echo "  ⚠ نصب انجام شد ولی سایت بالا نیومد"
fi
echo "=========================================="
echo ""
echo "  دامنه‌ها (اگه DNS ست شده):"
echo "    https://ehsanmorad.ir"
echo "    https://ehsan-morad.ir"
echo "    https://ehsanmorad.id.ir"
echo ""
echo "  اگه DNS هنوز ست نشده، سایت روی:"
echo "    http://31.70.76.10:3000"
echo ""
echo "  ورود ادمین:"
echo "    https://ehsanmorad.ir#admin"
echo "    username: admin"
echo "    password: admin123"
echo "    ⚠️ حتماً از Settings رمز رو عوض کن!"
echo ""
echo "  دستورات:"
echo "    docker compose logs -f        # لاگ همه"
echo "    docker compose logs -f caddy  # لاگ Caddy (SSL)"
echo "    docker compose restart        # restart"
echo "    docker compose down           # توقف"
echo ""
echo "=========================================="
