# Personal Site

## نصب (۳ دستور)

```bash
unzip personal-site.zip
cd personal-site
sudo ./install.sh
```

## دامنه‌ها (با SSL خودکار)

- https://ehsanmorad.ir
- https://ehsan-morad.ir
- https://ehsanmorad.id.ir

## ورود ادمین

- URL: `https://ehsanmorad.ir#admin`
- username: `admin`
- password: `admin123`
- ⚠️ از Settings رمز رو عوض کن!

## دستورات

```bash
docker compose logs -f        # لاگ
docker compose logs -f caddy # لاگ Caddy (SSL)
docker compose restart        # restart
docker compose down           # توقف
docker compose up -d          # اجرا
```

## نکته مهم

DNS رو ست کن (A record به 31.70.76.10):
- ehsanmorad.ir → 31.70.76.10
- www.ehsanmorad.ir → 31.70.76.10
- ehsan-morad.ir → 31.70.76.10
- www.ehsan-morad.ir → 31.70.76.10
- ehsanmorad.id.ir → 31.70.76.10
- www.ehsanmorad.id.ir → 31.70.76.10

Caddy خودش SSL می‌گیره (Let's Encrypt).
