# Personal Site

## نصب (۳ دستور)

```bash
unzip personal-site.zip
cd personal-site
sudo ./install.sh
```

## ورود ادمین

- URL: `http://YOUR_IP:3000#admin`
- username: `admin`
- password: `admin123`
- ⚠️ از Settings رمز رو عوض کن!

## دستورات

```bash
docker compose logs -f        # لاگ
docker compose restart        # restart
docker compose down           # توقف
docker compose up -d          # اجرا
```
