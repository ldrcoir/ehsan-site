# Personal Site

## نصب (۳ قدم)

```bash
# ۱. Extract
unzip personal-site.zip
cd personal-site

# ۲. اجرا
docker compose up -d --build

# ۳. صبر ۶۰ ثانیه، بعد تست
curl http://localhost:3000/
```

## ورود ادمین

- URL: `http://YOUR_IP:3000#admin`
- username: `admin`
- password: `admin123`
- ⚠️ از Settings رمز رو عوض کن!

## دامنه‌ها (ست شده)

- ehsanmorad.ir
- ehsan-morad.ir
- ehsanmorad.id.ir
- 31.70.76.10

## دستورات

```bash
docker compose logs -f        # لاگ
docker compose restart        # restart
docker compose down           # توقف
docker compose up -d --build  # بازسازی
```
