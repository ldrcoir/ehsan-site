# Personal Site — EhsanMorad

## Quick Start

```bash
# 1. Extract
unzip EhsanMorad-site-final.zip
cd personal-site

# 2. Run with Docker
docker-compose up -d --build

# 3. Wait 60 seconds, then check
curl http://localhost:3000/
# Should return HTTP 200
```

## First Time Setup

### 1. Change SESSION_SECRET (IMPORTANT!)

```bash
# Generate a random secret:
openssl rand -hex 32
# Copy the output, then:
nano .env
# Replace SESSION_SECRET="change-this-to-a-random-secret" with your generated secret
```

Then rebuild: `docker-compose up -d --build`

### 2. Change Admin Password (IMPORTANT!)

- URL: http://localhost:3000#admin (or Ctrl+Shift+A)
- Username: admin
- Password: admin123
- Change password from Settings tab immediately!

### 3. Configure Domains (already done for you)

Your domains are already configured:
- ehsanmorad.ir
- ehsan-morad.ir
- ehsanmorad.id.ir
- 31.70.76.10 (VPS IP)

If you need to add more domains, edit:
- src/app/page.tsx → authorizedDomains array
- src/lib/canvas-protect.ts → AUTHORIZED_DOMAINS array

### 4. Personalize Your Site

Edit src/lib/content.ts:
- handle: your username
- fullName: your name
- tagline: your tagline
- email: your email

Or use admin panel (recommended):
- Content tab: books, articles, tutorials
- Text tab: 36 editable texts
- Themes tab: custom theme builder

## User Login (Access Control)

- URL: http://localhost:3000/user-login
- Admin → Users tab → New User
- Set allowed hours, days, expiry

## AI Chat

The chat works in demo mode by default. To enable real AI:
- Admin → Settings → AI Providers
- Add API key for OpenAI, Anthropic, Groq, or OpenRouter
- Or use local Ollama

## Useful Commands

```bash
docker-compose logs -f          # View logs
docker-compose restart          # Restart site
docker-compose down             # Stop site
docker-compose up -d --build    # Rebuild after changes
```

## Version

V19.3 — 2026-09-03
