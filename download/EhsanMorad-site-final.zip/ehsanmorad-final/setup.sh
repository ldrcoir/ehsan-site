#!/bin/bash
# setup.sh — one-command setup for EhsanMorad site on VPS
# Run as root: sudo ./setup.sh

set -e

echo "=========================================="
echo "  EhsanMorad Site Setup"
echo "  IP: 31.70.76.10"
echo "  Domains: ehsanmorad.ir, ehsan-morad.ir, ehsanmorad.id.ir"
echo "=========================================="

# 1. Install Docker
echo "[1/5] Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    echo "  ✅ Docker installed"
else
    echo "  ✅ Docker already installed"
fi

# 2. Install Caddy
echo "[2/5] Installing Caddy..."
if ! command -v caddy &> /dev/null; then
    apt update
    apt install -y debian-keyring debian-archive-keyring apt-transport-https curl
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
    apt update
    apt install -y caddy
    echo "  ✅ Caddy installed"
else
    echo "  ✅ Caddy already installed"
fi

# 3. Configure Caddy
echo "[3/5] Configuring Caddy..."
cp personal-site/Caddyfile /etc/caddy/Caddyfile
systemctl restart caddy
systemctl enable caddy
echo "  ✅ Caddy configured"

# 4. Start site
echo "[4/5] Starting site..."
cd personal-site
docker-compose up -d --build
echo "  Waiting 60 seconds for startup..."
sleep 60
if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ | grep -q "200"; then
    echo "  ✅ Site is running on localhost:3000"
else
    echo "  ⚠ Check: docker-compose logs -f"
fi
cd ..

# 5. Firewall
echo "[5/5] Setting up firewall..."
apt install -y ufw 2>/dev/null || true
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
echo "  ✅ Firewall configured (ports 22, 80, 443 open)"

# Generate SESSION_SECRET
SECRET=$(openssl rand -hex 32)
cd personal-site
sed -i "s/SESSION_SECRET=.*/SESSION_SECRET=\"$SECRET\"/g" .env
echo ""
echo "=========================================="
echo "  ✅ Setup complete!"
echo "=========================================="
echo ""
echo "  Your sites:"
echo "    https://ehsanmorad.ir"
echo "    https://ehsan-morad.ir"
echo "    https://ehsanmorad.id.ir"
echo ""
echo "  Admin login:"
echo "    https://ehsanmorad.ir#admin"
echo "    username: admin"
echo "    password: admin123"
echo "    ⚠️ Change password from Settings tab!"
echo ""
echo "  Useful commands:"
echo "    cd personal-site && docker-compose logs -f"
echo "    cd personal-site && docker-compose restart"
echo "    sudo systemctl status caddy"
echo ""
echo "=========================================="
