# Personal Site (بدون Docker)

## نصب (سبک — ۵۰۰ مگ فضا)

```bash
unzip ehsan-site-direct.zip
cd personal-site
sudo ./install.sh
```

## دامنه‌ها

- https://ehsanmorad.ir
- https://ehsan-morad.ir
- https://ehsanmorad.id.ir

## دستورات

```bash
systemctl status personal-site     # وضعیت
systemctl restart personal-site    # restart
journalctl -u personal-site -f     # لاگ
```
