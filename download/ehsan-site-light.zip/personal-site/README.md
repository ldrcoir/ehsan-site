# Personal Site (نسخه سبک)

## فضای لازم: ~۸۰۰ مگ

```bash
unzip ehsan-site-light.zip
cd personal-site
sudo ./install.sh
```

## دامنه‌ها
- https://ehsanmorad.ir
- https://ehsan-morad.ir
- https://ehsanmorad.id.ir

## دستورات
```bash
systemctl status personal-site
systemctl restart personal-site
journalctl -u personal-site -f
```
