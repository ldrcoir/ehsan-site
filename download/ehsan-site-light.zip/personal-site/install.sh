#!/bin/bash
set -e
echo "=========================================="
echo "  نصب سایت سبک (برای VPS با فضای کم)"
echo "  حداکثر فضای لازم: ۸۰۰ مگ"
echo "=========================================="
echo ""

echo "[1/9] نصب Node.js 22..."
if command -v node &> /dev/null; then
    NODE_VER=$(node -v | sed 's/v//' | cut -d. -f1)
    if [ "$NODE_VER" -ge 20 ]; then
        echo "  ✅ Node.js نصبه ($(node -v))"
    else
        curl -fsSL https://deb.nodesource.com/setup_22.x | bash!
        apt install -y nodejs
        echo "  ✅ Node.js نصب شد ($(node -v))"
    fi
else
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt install -y nodejs
    echo "  ✅ Node.js نصب شد ($(node -v))"
fi

echo ""
echo "[2/9] نصب Nginx و Certbot..."
if ! command -v nginx &> /dev/null; then
    apt update
    apt install -y nginx certbot python3-certbot-nginx sqlite3 python3
    systemctl enable nginx
    systemctl start nginx
    echo "  ✅ Nginx نصب شد"
else
    apt install -y certbot python3-certbot-nginx sqlite3 python3 2>/dev/null || true
    echo "  ✅ Nginx نصبه"
fi

echo ""
echo "[3/9] فایروال..."
ufw allow 22/tcp 2>/dev/null || true
ufw allow 80/tcp 2>/dev/null || true
ufw allow 443/tcp 2>/dev/null || true
ufw allow 3000/tcp 2>/dev/null || true
echo "  ✅ فایروال ست شد"

echo ""
echo "[4/9] نصب وابستگی‌های dev (برای build)..."
npm config set registry https://registry.npmmirror.com
npm install --no-audit --no-fund 2>&1 | tail -3
echo "  ✅ وابستگی‌ها نصب شد"

echo ""
echo "[5/9] تنظیم دیتابیس..."
npx prisma generate 2>&1 | tail -2
npx prisma db push --accept-data-loss 2>&1 | tail -2
mkdir -p db
touch db/custom.db

TABLES=$(sqlite3 db/custom.db "SELECT count(*) FROM sqlite_master WHERE type='table';" 2>/dev/null || echo "0")
if [ "$TABLES" = "0" ] || [ -z "$TABLES" ]; then
    echo "  seeding..."
    python3 scripts/seed_content.py 2>&1 | tail -2 || true
    python3 scripts/seed_equipment.py 2>&1 | tail -2 || true
    python3 scripts/seed_texts.py 2>&1 | tail -2 || true
    python3 scripts/seed_access_users.py 2>&1 | tail -2 || true
fi
echo "  ✅ دیتابیس آماده"

echo ""
echo "[6/9] SESSION_SECRET..."
SECRET=$(openssl rand -hex 32)
if [ ! -f ".env" ]; then
    cat > .env << EOF
DATABASE_URL="file:./db/custom.db"
NODE_ENV="production"
PORT=3000
HOSTNAME="0.0.0.0"
SESSION_SECRET="$SECRET"
EOF
else
    if grep -q "SESSION_SECRET" .env; then
        sed -i "s/SESSION_SECRET=.*/SESSION_SECRET=\"$SECRET\"/g" .env
    else
        echo "SESSION_SECRET=\"$SECRET\"" >> .env
    fi
fi
echo "  ✅ SESSION_SECRET تولید شد"

echo ""
echo "[7/9] build سایت..."
npm run build 2>&1 | tail -5
echo "  ✅ build شد"

echo ""
echo "[8/9] پاک‌سازی (حذف وابستگی‌های اضافی برای صرفه‌جویی در فضا)..."
npm prune --production 2>&1 | tail -3
echo "  ✅ پاک شد"
echo "  فضای فعلی node_modules:"
du -sh node_modules 2>/dev/null || echo "  (نامشخص)"

echo ""
echo "[9/9] اجرای سایت..."
cat > /etc/systemd/system/personal-site.service << EOF
[Unit]
Description=Personal Site
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$(pwd)
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable personal-site
systemctl start personal-site
sleep 10

# Nginx
cp nginx-ehsanmorad.conf /etc/nginx/sites-available/nginx-ehsanmorad.conf 2>/dev/null || true
ln -sf /etc/nginx/sites-available/nginx-ehsanmorad.conf /etc/nginx/sites-enabled/nginx-ehsanmorad.conf 2>/dev/null || true
rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true
nginx -t 2>&1 && systemctl reload nginx

# تست
if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null | grep -q "200"; then
    echo "  ✅ سایت بالا اومد"
else
    echo "  ⚠ چک کن: systemctl status personal-site"
fi

# SSL
echo ""
read -p "DNS ست شده؟ (y/n): " DNS_OK
if [ "$DNS_OK" = "y" ] || [ "$DNS_OK" = "Y" ]; then
    for domain in ehsanmorad.ir ehsan-morad.ir ehsanmorad.id.ir; do
        certbot --nginx -d $domain -d www.$domain --non-interactive --agree-tos -m admin@$domain --redirect 2>&1 | tail -3 || true
    done
    systemctl reload nginx
fi

echo ""
echo "=========================================="
echo "  ✅ نصب کامل شد!"
echo "=========================================="
echo ""
echo "  فضای استفاده شده:"
du -sh . 2>/dev/null || echo "  (نامشخص)"
echo ""
echo "  دامنه‌ها:"
echo "    https://ehsanmorad.ir"
echo "    https://ehsan-morad.ir"
echo "    https://ehsanmorad.id.ir"
echo ""
echo "  یا: http://31.70.76.10:3000"
echo ""
echo "  ادمین: https://ehsanmorad.ir#admin"
echo "  username: admin"
echo "  password: admin123"
echo "  ⚠️ از Settings رمز رو عوض کن!"
echo ""
echo "  دستورات:"
echo "    systemctl status personal-site"
echo "    systemctl restart personal-site"
echo "    journalctl -u personal-site -f"
echo ""
echo "=========================================="
