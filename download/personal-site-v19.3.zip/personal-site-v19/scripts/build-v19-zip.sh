#!/bin/bash
# ============================================================================
# build-v19-zip.sh — ساخت فایل zip کامل قابل اجرا از extract
# ============================================================================
# این اسکریپت یه zip می‌سازه که:
# - شامل همه‌ی سورس کد هست
# - شامل package.json و bun.lockc هست
# - شامل prisma schema هست
# - شامل scripts ها هست
# - شامل Dockerfile و docker-compose.yml هست
# - شامل دیتابیس اولیه هست (با admin پیش‌فرض)
# - node_modules شامل نمی‌شه (docker-compose up خودش نصب می‌کنه)
# ============================================================================

set -e

cd /home/z/my-project

OUTPUT="download/personal-site-v19.3.zip"
TMP_DIR="/tmp/personal-site-v19"

echo "🧹 Cleaning up..."
rm -rf "$TMP_DIR"
rm -f "$OUTPUT"

echo "📦 Copying files..."
mkdir -p "$TMP_DIR"

# فایل‌های اصلی
cp -r src/ "$TMP_DIR/"
cp -r prisma/ "$TMP_DIR/"
cp -r scripts/ "$TMP_DIR/"
cp -r public/ "$TMP_DIR/"
cp -r mini-services/ "$TMP_DIR/" 2>/dev/null || true
cp -r examples/ "$TMP_DIR/" 2>/dev/null || true

# فایل‌های config
cp package.json bun.lock* "$TMP_DIR/"
cp next.config.ts tsconfig.json "$TMP_DIR/"
cp postcss.config.mjs components.json "$TMP_DIR/" 2>/dev/null || true
cp .dockerignore .gitignore "$TMP_DIR/" 2>/dev/null || true

# فایل .env.example با محتوای generic (بدون آدرس localhost سرور توسعه)
cat > "$TMP_DIR/.env.example" << 'ENVEOF'
# Database
DATABASE_URL="file:./db/custom.db"

# Server
NODE_ENV="production"
PORT=3000
HOSTNAME="0.0.0.0"

# Session secret (CHANGE THIS to a random string!)
SESSION_SECRET="change-this-to-a-random-secret"

# Optional: AI providers (leave empty to use default )
# OPENAI_API_KEY=""
# ANTHROPIC_API_KEY=""
# GROQ_API_KEY=""
# OPENROUTER_API_KEY=""
ENVEOF

# اگه .env وجود نداره، یه نسخه‌ی پیش‌فرض بساز
if [ ! -f "$TMP_DIR/.env" ]; then
  cp "$TMP_DIR/.env.example" "$TMP_DIR/.env"
fi

# Docker
cp Dockerfile docker-compose.yml docker-entrypoint.sh "$TMP_DIR/"
chmod +x "$TMP_DIR/docker-entrypoint.sh"

# Caddyfile (اگه باشه)
cp Caddyfile "$TMP_DIR/" 2>/dev/null || true

# دیتابیس اولیه — اگه نبود، Docker خودش می‌سازه
mkdir -p "$TMP_DIR/db"
cp db/custom.db "$TMP_DIR/db/" 2>/dev/null || echo "  (no existing db, Docker will create on first run)"

# README
cat > "$TMP_DIR/README.md" << 'EOF'
# Personal Site

A full-featured personal portfolio website with terminal/RF theme.

## Quick Start

```bash
# 1. Extract
unzip personal-site-v19.3.zip
cd personal-site-v19

# 2. Run with Docker
docker-compose up -d

# 3. View in browser
# Site will be at http://localhost:3000
```

## First Time Setup

### 1. Change Admin Password (IMPORTANT!)

Default credentials:
- URL: http://localhost:3000#admin (or press Ctrl+Shift+A)
- Username: `admin`
- Password: `admin123`

⚠️ **Change the password immediately** from Settings tab in admin panel.

### 2. Add Your Domain

After deploying to your VPS with your domain, edit these files and add your domain:

**`src/app/page.tsx`** — find `authorizedDomains` array:
```typescript
const authorizedDomains = [
  "localhost",
  "127.0.0.1",
  "yourdomain.com",  // ← add your domain here
];
```

**`src/lib/canvas-protect.ts`** — find `AUTHORIZED_DOMAINS` array:
```typescript
const AUTHORIZED_DOMAINS = [
  "localhost",
  "127.0.0.1",
  "yourdomain.com",  // ← add your domain here
];
```

Then rebuild: `docker-compose up -d --build`

### 3. Personalize Your Site

Edit `src/lib/content.ts`:
- `handle` — your username/handle
- `fullName` — your name (in en/de/fa)
- `tagline` — your tagline
- `email` — your contact email
- `adminUsername` / `adminPassword` — admin credentials

Or use the admin panel (recommended) — all content is editable from there:
- Content tab — books, articles, tutorials, skills, equipment
- Text tab — 36 editable site texts
- Nav tab — navigation menu
- Themes tab — custom theme builder

### 4. Configure .env

The `.env` file is pre-configured for Docker. To customize:

```bash
# Edit .env
nano .env

# Key settings:
DATABASE_URL="file:./db/custom.db"
NODE_ENV="production"
PORT=3000
HOSTNAME="0.0.0.0"
SESSION_SECRET="change-this-to-a-random-secret"  # ← CHANGE THIS!

# Optional AI providers (leave empty for default ):
# OPENAI_API_KEY=""
# ANTHROPIC_API_KEY=""
# GROQ_API_KEY=""
# OPENROUTER_API_KEY=""
```

Then: `docker-compose up -d --build`

## User Login (Access Control)

Admin can create users with time-based access:

- URL: http://localhost:3000/user-login
- Admin → Users tab → New User
- Set allowed hours, days, expiry date
- Users can only access during their allowed time window

## Features

- Next.js 16 + TypeScript + Prisma + SQLite
- Matrix terminal theme (green on black)
- Signal Lab with oscilloscope + signal generator (AM/FM)
- AI chat with multiple providers
- Admin panel with 9 tabs
- User management with time-based access
- 7 themes + theme builder
- 3 languages (EN, DE, FA)
- PWA, RSS, Sitemap
- Anti-theft (domain lock, watermark, devtools detection)

## Transfer to New VPS

```bash
# On old VPS:
docker cp personal-site:/app/db/custom.db ./backup.db
tar -czf site-backup.tar.gz personal-site-v19/ backup.db

# On new VPS:
tar -xzf site-backup.tar.gz
cd personal-site-v19
docker-compose up -d
docker cp ../backup.db personal-site:/app/db/custom.db
docker-compose restart

# Remember to update your domain in:
# - src/app/page.tsx (authorizedDomains)
# - src/lib/canvas-protect.ts (AUTHORIZED_DOMAINS)
docker-compose up -d --build
```

## Project Structure

```
personal-site-v19/
├── src/
│   ├── app/
│   │   ├── page.tsx              # Main page
│   │   ├── layout.tsx            # HTML shell + viewport
│   │   ├── user-login/           # User login page
│   │   ├── user-dashboard/       # User dashboard
│   │   └── api/                  # API routes (25+)
│   ├── components/               # React components (21)
│   └── lib/                      # Utilities (auth, db, security, etc.)
├── prisma/
│   └── schema.prisma             # Database models (25+)
├── scripts/                      # Seed scripts + build helpers
├── public/                       # Static assets
├── db/                           # SQLite database
├── Dockerfile
├── docker-compose.yml
├── docker-entrypoint.sh
├── .env
└── README.md                     # This file
```

## Version

V19.3 — 2026-09-03

## Support

All source code has Persian line-by-line comments for easy understanding.
See `FULL_TUTORIAL_FA_V19.3.docx` for a complete 12-chapter tutorial in Persian.
EOF

# ساخت zip
echo "🗜️  Creating zip..."
cd /tmp
zip -r "/home/z/my-project/$OUTPUT" personal-site-v19/ -x "*/node_modules/*" "*/.next/*" "*/.git/*" > /dev/null

echo ""
echo "✅ Done!"
echo "   File: $OUTPUT"
ls -lh "/home/z/my-project/$OUTPUT"

# پاک‌سازی
rm -rf "$TMP_DIR"
