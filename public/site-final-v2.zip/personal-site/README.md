# Personal Site

## نصب

```bash
unzip site-final-v2.zip
cd personal-site
sudo ./install.sh
```

## ورود ادمین
- URL: `http://YOUR_IP:3000/user-login`
- username: `admin`
- password: `admin123`

## دستورات
```bash
systemctl status personal-site
systemctl restart personal-site
journalctl -u personal-site -f
```
