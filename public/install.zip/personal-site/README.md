# Personal Site

## نصب

```bash
unzip install.zip
cd personal-site
sudo ./install.sh
```

## ورود ادمین
- URL: `http://YOUR_IP:3000/user-login`
- username: `admin`
- password: `admin123`
- ⚠️ از Settings رمز رو عوض کن!

## دامنه‌ها
- ehsanmorad.ir
- ehsan-morad.ir
- ehsanmorad.id.ir

## آموزش هوش مصنوعی محلی
فایل OLLAMA_GUIDE_FA.md رو بخون.
