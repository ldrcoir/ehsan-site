# Personal Site V17.2

## Quick Install

```bash
wget https://github.com/ldrcoir/ehsan-site-private/raw/main/public/install-v17.2.zip
unzip install-v17.2.zip
cd personal-site
sudo ./install.sh
```

## Admin Login

- URL: `http://YOUR_IP:3000/user-login`
- Username: `admin`
- Password: `admin123`
- ⚠️ Change password immediately from Panel → Settings

## Features

- 📊 10-tab admin panel (Dashboard, Messages, Content, Texts, Nav, Themes, Users, Clips, Font, Settings)
- 🧠 AI Chat (OpenAI, Anthropic, Ollama, Groq)
- 📨 Contact form with mandatory reCAPTCHA + honeypot + time-trap
- 🤖 Bale + Telegram bot notifications
- 📧 Email forwarding (formsubmit.co — free)
- 🌐 3 languages (fa/en/de) with RTL support
- 🔤 5 selectable fonts
- 🎨 7 color themes + custom theme builder
- 🔒 Full security: middleware, CSP, CSRF, rate limit, session HMAC, bcrypt

## Security

- SESSION_SECRET strong (openssl rand -hex 32)
- Cookie: HttpOnly + Secure + SameSite=Strict
- CSRF protection via Origin check
- Rate limit: login 5/15min, contact/chat 8/15min, body size 1MB
- reCAPTCHA mandatory + fail-closed
- Honeypot + time-trap on contact form
- timingSafeEqual on all webhook secrets
- CSP + security headers (X-Frame-Options, X-Content-Type-Options, etc.)
- HSTS on HTTPS
- XSS prevention: nav href + tutorial embedUrl + book/article link scheme validation
- Standalone package: no dev database, no .env file (created by install.sh)

## Docs

- VERSION.txt — version history
- TUTORIAL_FA_V17.2.docx — comprehensive Persian tutorial (8 chapters)
- OLLAMA_GUIDE_FA.md — local AI guide
